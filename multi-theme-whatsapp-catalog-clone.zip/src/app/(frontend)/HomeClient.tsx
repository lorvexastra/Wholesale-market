"use client";
import React, { useState } from "react";
import { useTheme } from "@/context/ThemeContext";
import HeroBanner from "@/components/HeroBanner";
import ProductCard from "@/components/ProductCard";
import CategoryScroll from "@/components/CategoryScroll";
import Link from "next/link";
import { ArrowRight, Star, Users, Truck, Award } from "lucide-react";

interface Product {
  id: number;
  name: string;
  unit: string | null;
  priceLabel: string | null;
  imageUrl: string | null;
  description: string | null;
  tags: string | null;
  isFeatured: boolean | null;
  category?: { id: number; name: string; slug: string } | null;
}

interface Category {
  id: number;
  name: string;
  slug: string;
  imageUrl: string | null;
  description: string | null;
}

interface Banner {
  id: number;
  title: string;
  subtitle: string | null;
  imageUrl: string | null;
}

interface Props {
  banners: Banner[];
  categories: Category[];
  featuredProducts: Product[];
  productsByCategory: { category: Category; products: Product[] }[];
}

const STATS = [
  { icon: <Star size={20} />, value: "5+", label: "Years Experience" },
  { icon: <Users size={20} />, value: "500+", label: "Happy Clients" },
  { icon: <Truck size={20} />, value: "Daily", label: "Fresh Delivery" },
  { icon: <Award size={20} />, value: "100%", label: "Farm Fresh" },
];

export default function HomeClient({ banners, categories, featuredProducts, productsByCategory }: Props) {
  const { theme } = useTheme();
  const c = theme.colors;

  return (
    <div style={{ backgroundColor: c.background }}>
      {/* Hero */}
      <HeroBanner banners={banners} />

      {/* Stats bar */}
      <div style={{ backgroundColor: c.surface, borderBottom: `1px solid ${c.border}` }} className="py-6">
        <div className="max-w-6xl mx-auto px-4 grid grid-cols-4 gap-2">
          {STATS.map((s) => (
            <div key={s.label} className="flex flex-col items-center text-center">
              <div style={{ color: c.primary }} className="mb-1">{s.icon}</div>
              <p style={{ color: c.text, fontFamily: theme.fonts.heading }} className="font-bold text-lg leading-none">{s.value}</p>
              <p style={{ color: c.textMuted }} className="text-[10px] mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Categories */}
      <div className="max-w-6xl mx-auto px-4 pt-8 pb-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p style={{ color: c.primary }} className="text-xs uppercase tracking-widest font-semibold mb-1">Browse by</p>
            <h2 style={{ color: c.text, fontFamily: theme.fonts.heading }} className="text-xl font-bold">
              Categories
            </h2>
          </div>
          <Link href="/products" style={{ color: c.primary }} className="flex items-center gap-1 text-sm font-semibold">
            See All <ArrowRight size={14} />
          </Link>
        </div>
        
        {/* Category Grid */}
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
          {categories.slice(0, 6).map((cat) => {
            const emojis: Record<string, string> = {
              "leafy-vegetables": "🥬", "root-vegetables": "🥕", "gourds-melons": "🎃",
              "exotic-vegetables": "🥦", "fruits-pods": "🫑", "herbs-spices": "🌿",
            };
            return (
              <Link
                key={cat.id}
                href={`/products?category=${cat.slug}`}
                style={{ borderRadius: theme.borderRadius }}
                className="flex flex-col items-center gap-2 group"
              >
                <div
                  style={{
                    backgroundColor: c.surfaceAlt,
                    borderRadius: theme.borderRadius,
                    border: `1px solid ${c.border}`,
                    overflow: "hidden",
                  }}
                  className="w-full aspect-square relative group-hover:scale-105 transition-transform duration-200"
                >
                  {cat.imageUrl ? (
                    <img src={cat.imageUrl} alt={cat.name} className="w-full h-full object-cover" loading="lazy" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-3xl">
                      {emojis[cat.slug] ?? "🥗"}
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
                </div>
                <p style={{ color: c.text, fontFamily: theme.fonts.heading }} className="text-xs font-semibold text-center leading-tight">
                  {cat.name}
                </p>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Featured Products */}
      {featuredProducts.length > 0 && (
        <div className="max-w-6xl mx-auto px-4 py-8">
          <div className="flex items-center justify-between mb-5">
            <div>
              <p style={{ color: c.primary }} className="text-xs uppercase tracking-widest font-semibold mb-1">⭐ Handpicked</p>
              <h2 style={{ color: c.text, fontFamily: theme.fonts.heading }} className="text-xl font-bold">
                Featured Products
              </h2>
            </div>
            <Link href="/products?featured=true" style={{ color: c.primary }} className="flex items-center gap-1 text-sm font-semibold">
              View All <ArrowRight size={14} />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {featuredProducts.slice(0, 8).map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      )}

      {/* About strip */}
      <div style={{ background: theme.colors.heroBg }} className="py-10 px-4 my-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 style={{ fontFamily: theme.fonts.heading, color: "#fff" }} className="text-2xl font-bold mb-3">
            Why Choose Sardar Vegetable Market?
          </h2>
          <p className="text-white/80 text-sm leading-relaxed mb-6">
            We are a trusted online vegetables wholesaler and supplier in Surat. We provide all types of fresh and hygienic vegetables directly from farms. For over 5 years, we&apos;ve been supplying local hotels, restaurants, marriage &amp; event caterers, retail shops, and mandi buyers.
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { emoji: "🏨", text: "Hotels" },
              { emoji: "🍽️", text: "Restaurants" },
              { emoji: "💍", text: "Caterers" },
              { emoji: "🛒", text: "Retail Shops" },
            ].map((item) => (
              <div key={item.text} className="bg-white/10 backdrop-blur-sm rounded-2xl p-3 text-center">
                <span className="text-2xl block mb-1">{item.emoji}</span>
                <span className="text-white/90 text-xs font-semibold">{item.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Category product sections */}
      {productsByCategory.map(({ category, products: prods }) =>
        prods.length > 0 ? (
          <div key={category.id} className="max-w-6xl mx-auto px-4 py-6">
            <div className="flex items-center justify-between mb-4">
              <h2 style={{ color: c.text, fontFamily: theme.fonts.heading }} className="text-lg font-bold">
                {category.name}
              </h2>
              <Link
                href={`/products?category=${category.slug}`}
                style={{ color: c.primary }}
                className="flex items-center gap-1 text-sm font-semibold"
              >
                More <ArrowRight size={14} />
              </Link>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {prods.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        ) : null
      )}

      {/* WhatsApp CTA */}
      <div className="px-4 py-8 max-w-lg mx-auto text-center">
        <div
          style={{ backgroundColor: c.surface, borderRadius: theme.borderRadius, border: `1px solid ${c.border}` }}
          className="p-6"
        >
          <span className="text-4xl block mb-3">📱</span>
          <h3 style={{ color: c.text, fontFamily: theme.fonts.heading }} className="text-lg font-bold mb-2">
            Need Help Ordering?
          </h3>
          <p style={{ color: c.textMuted }} className="text-sm mb-4">
            Chat with us on WhatsApp and get the best wholesale prices for bulk orders.
          </p>
          <a
            href="https://wa.me/919876543210"
            target="_blank"
            rel="noopener noreferrer"
            style={{ backgroundColor: "#25D366", borderRadius: theme.borderRadius }}
            className="inline-flex items-center gap-2 px-6 py-3 text-white font-bold text-sm transition-all active:scale-95 hover:opacity-90"
          >
            💬 Chat on WhatsApp
          </a>
        </div>
      </div>
    </div>
  );
}
