"use client";
import React from "react";
import { useTheme } from "@/context/ThemeContext";
import { Award, Truck, Users, Clock, CheckCircle, Leaf } from "lucide-react";
import Link from "next/link";

export default function AboutPage() {
  const { theme, brandName } = useTheme();
  const c = theme.colors;

  return (
    <div style={{ backgroundColor: c.background }} className="min-h-screen">
      {/* Hero */}
      <div style={{ background: theme.colors.heroBg }} className="px-4 py-14 text-center">
        <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm px-4 py-2 rounded-full mb-4">
          <Leaf size={16} color="#fff" />
          <span className="text-white text-sm font-semibold">Est. 2019 | Surat, Gujarat</span>
        </div>
        <h1
          style={{ fontFamily: theme.fonts.heading, color: "#fff" }}
          className="text-3xl sm:text-4xl font-bold mb-4 max-w-2xl mx-auto"
        >
          Fresh From Farms, Delivered To You
        </h1>
        <p className="text-white/80 text-sm sm:text-base max-w-xl mx-auto leading-relaxed">
          We are <strong className="text-white">{brandName}</strong> — a trusted online vegetables wholesaler and supplier in Surat, bringing the freshest produce directly from farms to your business.
        </p>
      </div>

      {/* Stats */}
      <div style={{ backgroundColor: c.surface }} className="py-8">
        <div className="max-w-4xl mx-auto px-4 grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { value: "5+", label: "Years in Business", icon: "📅" },
            { value: "500+", label: "Happy Customers", icon: "😊" },
            { value: "50+", label: "Vegetable Varieties", icon: "🥬" },
            { value: "Daily", label: "Fresh Supply", icon: "🚛" },
          ].map((stat) => (
            <div
              key={stat.label}
              style={{ backgroundColor: c.surfaceAlt, borderRadius: theme.borderRadius, border: `1px solid ${c.border}` }}
              className="flex flex-col items-center p-4 text-center"
            >
              <span className="text-2xl mb-2">{stat.icon}</span>
              <p style={{ color: c.primary, fontFamily: theme.fonts.heading }} className="text-2xl font-bold">
                {stat.value}
              </p>
              <p style={{ color: c.textMuted }} className="text-xs mt-1">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Our Story */}
      <div className="max-w-3xl mx-auto px-4 py-10">
        <div
          style={{ backgroundColor: c.surface, borderRadius: theme.borderRadius, border: `1px solid ${c.border}` }}
          className="p-6 sm:p-8"
        >
          <h2 style={{ color: c.text, fontFamily: theme.fonts.heading }} className="text-2xl font-bold mb-4">
            Our Story
          </h2>
          <div style={{ color: c.textMuted }} className="space-y-4 text-sm leading-relaxed">
            <p>
              We are <strong style={{ color: c.text }}>{brandName}</strong>, a trusted online vegetables wholesaler and supplier in Surat. We provide all types of <strong style={{ color: c.text }}>fresh and hygienic vegetables directly from farms</strong>.
            </p>
            <p>
              From the last <strong style={{ color: c.text }}>5 years</strong>, we are supplying vegetables to <strong style={{ color: c.text }}>local hotels, restaurants, marriage &amp; event caterers, retail shops, and mandi buyers</strong>.
            </p>
            <p>
              After a successful offline business, we expanded our services to <strong style={{ color: c.text }}>online vegetables supply in Surat</strong>, so customers can easily order vegetables without visiting the market.
            </p>
            <p>
              We did market research and found that many <strong style={{ color: c.text }}>hotel, restaurant, marriage &amp; event, retail, and mandi owners</strong> face difficulty buying vegetables from <strong style={{ color: c.text }}>Sardar Vegetable Market</strong> because the market starts <strong style={{ color: c.text }}>very early in the morning</strong>. Due to time and transportation issues, many buyers miss the best quality vegetables.
            </p>
            <p>
              To solve this problem, we provide <strong style={{ color: c.text }}>online vegetables at the same Sardar Vegetable Market Surat price</strong>. Now you can order vegetables online and get <strong style={{ color: c.text }}>fresh farm vegetables delivered on time</strong>, without visiting the market early morning.
            </p>
          </div>
        </div>
      </div>

      {/* Why Choose Us */}
      <div className="max-w-3xl mx-auto px-4 pb-10">
        <h2 style={{ color: c.text, fontFamily: theme.fonts.heading }} className="text-2xl font-bold mb-6 text-center">
          Why Choose Us?
        </h2>
        <div className="grid sm:grid-cols-2 gap-4">
          {[
            { icon: <CheckCircle size={20} />, title: "Quality & Freshness", desc: "We are committed to quality, freshness, hygiene, and reliable supply for all wholesale vegetable buyers." },
            { icon: <Truck size={20} />, title: "Daily Fresh Delivery", desc: "Fresh farm vegetables delivered on time daily. No need to visit the market at early morning hours." },
            { icon: <Award size={20} />, title: "Market Rate Pricing", desc: "Get vegetables at the same Sardar Vegetable Market Surat price — directly, no middlemen, no markup." },
            { icon: <Users size={20} />, title: "Trusted by 500+ Clients", desc: "Hotels, restaurants, caterers, retail shops and mandi buyers — all trust us for bulk fresh supplies." },
            { icon: <Clock size={20} />, title: "Convenient Ordering", desc: "Order online anytime without visiting the market early in the morning. Simple WhatsApp ordering." },
            { icon: <Leaf size={20} />, title: "Farm Direct Sourcing", desc: "We source vegetables directly from farms ensuring maximum freshness and minimum handling." },
          ].map((item) => (
            <div
              key={item.title}
              style={{ backgroundColor: c.surface, borderRadius: theme.borderRadius, border: `1px solid ${c.border}` }}
              className="flex gap-4 p-4"
            >
              <div
                style={{ backgroundColor: c.primaryLight, color: c.primary, borderRadius: theme.borderRadius }}
                className="w-10 h-10 flex items-center justify-center flex-shrink-0"
              >
                {item.icon}
              </div>
              <div>
                <h3 style={{ color: c.text, fontFamily: theme.fonts.heading }} className="font-bold text-sm mb-1">
                  {item.title}
                </h3>
                <p style={{ color: c.textMuted }} className="text-xs leading-relaxed">
                  {item.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* We Serve */}
      <div style={{ backgroundColor: c.surface, borderTop: `1px solid ${c.border}`, borderBottom: `1px solid ${c.border}` }} className="py-10 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 style={{ color: c.text, fontFamily: theme.fonts.heading }} className="text-2xl font-bold mb-6">
            Who We Serve
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { emoji: "🏨", title: "Hotels", desc: "Daily bulk vegetable supply" },
              { emoji: "🍽️", title: "Restaurants", desc: "Fresh ingredients every day" },
              { emoji: "💍", title: "Caterers", desc: "Event & wedding orders" },
              { emoji: "🛒", title: "Retail Shops", desc: "Reseller quantities" },
            ].map((item) => (
              <div
                key={item.title}
                style={{ backgroundColor: c.surfaceAlt, borderRadius: theme.borderRadius, border: `1px solid ${c.border}` }}
                className="p-4 text-center"
              >
                <span className="text-3xl block mb-2">{item.emoji}</span>
                <p style={{ color: c.text, fontFamily: theme.fonts.heading }} className="font-bold text-sm mb-1">{item.title}</p>
                <p style={{ color: c.textMuted }} className="text-xs">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="py-10 px-4 text-center">
        <div className="max-w-sm mx-auto">
          <h3 style={{ color: c.text, fontFamily: theme.fonts.heading }} className="text-xl font-bold mb-2">
            Ready to Order?
          </h3>
          <p style={{ color: c.textMuted }} className="text-sm mb-5">
            Browse our fresh vegetable catalogue and send an enquiry via WhatsApp.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              href="/products"
              style={{ backgroundColor: c.btnPrimary, color: c.btnPrimaryText, borderRadius: theme.borderRadius }}
              className="px-6 py-3 font-bold text-sm transition-all active:scale-95 hover:opacity-90"
            >
              Browse Products
            </Link>
            <Link
              href="/contact"
              style={{ backgroundColor: c.btnSecondary, color: c.btnSecondaryText, borderRadius: theme.borderRadius, border: `1px solid ${c.border}` }}
              className="px-6 py-3 font-bold text-sm transition-all active:scale-95 hover:opacity-90"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
