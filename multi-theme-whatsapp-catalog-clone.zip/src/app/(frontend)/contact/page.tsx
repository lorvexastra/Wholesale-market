"use client";
import React, { useState } from "react";
import { useTheme } from "@/context/ThemeContext";
import { Phone, Mail, MapPin, Clock, MessageCircle, Send } from "lucide-react";

export default function ContactPage() {
  const { theme, whatsappNumber } = useTheme();
  const c = theme.colors;
  const [name, setName] = useState("");
  const [msg, setMsg] = useState("");

  const handleWhatsAppContact = () => {
    const text = encodeURIComponent(
      `Hi! My name is ${name || "Customer"}.\n\n${msg || "I'd like to enquire about vegetable supply."}\n\nPlease contact me. Thank you!`
    );
    window.open(`https://wa.me/${whatsappNumber}?text=${text}`, "_blank");
  };

  return (
    <div style={{ backgroundColor: c.background }} className="min-h-screen">
      {/* Header */}
      <div style={{ background: theme.colors.heroBg }} className="px-4 py-12 text-center">
        <h1 style={{ fontFamily: theme.fonts.heading, color: "#fff" }} className="text-3xl font-bold mb-3">
          Contact Us
        </h1>
        <p className="text-white/80 text-sm max-w-md mx-auto">
          Get in touch for wholesale enquiries, bulk orders, or any questions. We&apos;re happy to help!
        </p>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-8 grid sm:grid-cols-2 gap-6">
        {/* Contact Info */}
        <div className="space-y-4">
          <h2 style={{ color: c.text, fontFamily: theme.fonts.heading }} className="text-xl font-bold">
            Get in Touch
          </h2>
          {[
            { icon: <Phone size={18} />, label: "Phone", value: "+91 98765 43210", href: "tel:+919876543210" },
            { icon: <MessageCircle size={18} />, label: "WhatsApp", value: "Chat with us", href: `https://wa.me/${whatsappNumber}` },
            { icon: <Mail size={18} />, label: "Email", value: "info@sardarvegetablemarket.in", href: "mailto:info@sardarvegetablemarket.in" },
            { icon: <MapPin size={18} />, label: "Address", value: "Sardar Vegetable Market, Surat, Gujarat - 395003", href: null },
            { icon: <Clock size={18} />, label: "Support Hours", value: "Mon - Sun: 4:00 AM – 10:00 AM", href: null },
          ].map((item) => (
            <div
              key={item.label}
              style={{ backgroundColor: c.surface, borderRadius: theme.borderRadius, border: `1px solid ${c.border}` }}
              className="flex gap-3 p-4"
            >
              <div style={{ color: c.primary, backgroundColor: c.primaryLight, borderRadius: theme.borderRadius }}
                className="w-9 h-9 flex items-center justify-center flex-shrink-0"
              >
                {item.icon}
              </div>
              <div>
                <p style={{ color: c.textMuted }} className="text-xs mb-0.5">{item.label}</p>
                {item.href ? (
                  <a
                    href={item.href}
                    target={item.href.startsWith("http") ? "_blank" : undefined}
                    rel="noopener noreferrer"
                    style={{ color: c.primary, fontFamily: theme.fonts.heading }}
                    className="text-sm font-semibold hover:underline"
                  >
                    {item.value}
                  </a>
                ) : (
                  <p style={{ color: c.text, fontFamily: theme.fonts.heading }} className="text-sm font-semibold">
                    {item.value}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Contact Form */}
        <div>
          <h2 style={{ color: c.text, fontFamily: theme.fonts.heading }} className="text-xl font-bold mb-4">
            Send Enquiry
          </h2>
          <div
            style={{ backgroundColor: c.surface, borderRadius: theme.borderRadius, border: `1px solid ${c.border}` }}
            className="p-5 space-y-4"
          >
            <div>
              <label style={{ color: c.textMuted }} className="text-xs font-semibold mb-1.5 block uppercase tracking-wide">
                Your Name
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your name"
                style={{
                  backgroundColor: c.surfaceAlt,
                  border: `1px solid ${c.border}`,
                  color: c.text,
                  borderRadius: theme.borderRadius,
                  fontFamily: theme.fonts.body,
                }}
                className="w-full px-3 py-2.5 text-sm outline-none focus:ring-2 transition-all"
              />
            </div>
            <div>
              <label style={{ color: c.textMuted }} className="text-xs font-semibold mb-1.5 block uppercase tracking-wide">
                Your Message / Enquiry
              </label>
              <textarea
                rows={5}
                value={msg}
                onChange={(e) => setMsg(e.target.value)}
                placeholder="Tell us about your requirements — which vegetables, quantity, delivery location..."
                style={{
                  backgroundColor: c.surfaceAlt,
                  border: `1px solid ${c.border}`,
                  color: c.text,
                  borderRadius: theme.borderRadius,
                  fontFamily: theme.fonts.body,
                  resize: "none",
                }}
                className="w-full px-3 py-2.5 text-sm outline-none transition-all"
              />
            </div>
            <button
              onClick={handleWhatsAppContact}
              style={{ backgroundColor: "#25D366", borderRadius: theme.borderRadius }}
              className="w-full flex items-center justify-center gap-2 py-3 text-white font-bold text-sm transition-all active:scale-95 hover:opacity-90"
            >
              <MessageCircle size={17} />
              Send via WhatsApp
            </button>
            <p style={{ color: c.textMuted }} className="text-[10px] text-center">
              Clicking this button will open WhatsApp with your message pre-filled.
            </p>
          </div>

          {/* Bulk Order card */}
          <div
            style={{ backgroundColor: c.primaryLight, borderRadius: theme.borderRadius, border: `1px solid ${c.primary}30` }}
            className="mt-4 p-4"
          >
            <p style={{ color: c.primary, fontFamily: theme.fonts.heading }} className="font-bold text-sm mb-1">
              🛒 Bulk Order Enquiry?
            </p>
            <p style={{ color: c.textMuted }} className="text-xs leading-relaxed mb-3">
              For large quantity orders for hotels, restaurants, or events — add multiple products to your cart and send a single WhatsApp enquiry.
            </p>
            <a
              href="/products"
              style={{ backgroundColor: c.primary, color: "#fff", borderRadius: theme.borderRadius }}
              className="inline-block px-4 py-2 text-xs font-bold transition-all active:scale-95 hover:opacity-90"
            >
              Browse & Add to Cart
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
