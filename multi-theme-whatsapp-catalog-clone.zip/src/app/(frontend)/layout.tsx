import React from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PWAInstall from "@/components/PWAInstall";
import { db } from "@/db";
import { footerSettings } from "@/db/schema";

async function getFooterData() {
  try {
    const [data] = await db.select().from(footerSettings).limit(1);
    return data ?? null;
  } catch {
    return null;
  }
}

export default async function FrontendLayout({ children }: { children: React.ReactNode }) {
  const footer = await getFooterData();
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1">{children}</main>
      <Footer data={footer} />
      <PWAInstall />
      {/* PWA bottom safe area spacer */}
      <div className="safe-area-pb" />
    </div>
  );
}
