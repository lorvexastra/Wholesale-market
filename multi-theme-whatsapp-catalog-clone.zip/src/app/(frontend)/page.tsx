import React from "react";
import { db } from "@/db";
import { products, categories, banners, footerSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import HeroBanner from "@/components/HeroBanner";
import ProductCard from "@/components/ProductCard";
import CategoryScroll from "@/components/CategoryScroll";
import HomeClient from "./HomeClient";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

async function getData() {
  try {
    const allBanners = await db.select().from(banners).where(eq(banners.isActive, true));
    const allCategories = await db.select().from(categories).where(eq(categories.isActive, true));
    const allProducts = await db.select().from(products).where(eq(products.isActive, true));
    const [footer] = await db.select().from(footerSettings).limit(1);

    const catMap = Object.fromEntries(allCategories.map((c) => [c.id, c]));
    const featuredProducts = allProducts
      .filter((p) => p.isFeatured)
      .map((p) => ({ ...p, category: p.categoryId ? catMap[p.categoryId] : null }));

    return {
      banners: allBanners.sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0)),
      categories: allCategories.sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0)),
      featuredProducts,
      allProducts: allProducts.map((p) => ({ ...p, category: p.categoryId ? catMap[p.categoryId] : null })),
      footer: footer ?? null,
    };
  } catch {
    return { banners: [], categories: [], featuredProducts: [], allProducts: [], footer: null };
  }
}

export default async function HomePage() {
  const { banners: heroBanners, categories: cats, featuredProducts, allProducts } = await getData();

  // Group products by category for sections
  const productsByCategory = cats.map((cat) => ({
    category: cat,
    products: allProducts.filter((p) => p.categoryId === cat.id).slice(0, 6),
  }));

  return (
    <HomeClient
      banners={heroBanners}
      categories={cats}
      featuredProducts={featuredProducts}
      productsByCategory={productsByCategory}
    />
  );
}
