"use client";
import React, { useState, useMemo, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { useTheme } from "@/context/ThemeContext";
import ProductCard from "@/components/ProductCard";
import CategoryScroll from "@/components/CategoryScroll";
import { Search, LayoutGrid, List } from "lucide-react";

interface Product {
  id: number;
  name: string;
  unit: string | null;
  priceLabel: string | null;
  imageUrl: string | null;
  description: string | null;
  tags: string | null;
  isFeatured: boolean | null;
  category?: { id: number; name: string; slug: string } | null;
}

interface Category {
  id: number;
  name: string;
  slug: string;
  imageUrl: string | null;
  description: string | null;
}

function ProductsInner({ products, categories }: { products: Product[]; categories: Category[] }) {
  const { theme } = useTheme();
  const c = theme.colors;
  const searchParams = useSearchParams();
  const [search, setSearch] = useState("");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [sortBy, setSortBy] = useState("default");

  const categorySlug = searchParams.get("category") ?? undefined;
  const featuredOnly = searchParams.get("featured") === "true";

  const filtered = useMemo(() => {
    let result = [...products];
    if (categorySlug) result = result.filter((p) => p.category?.slug === categorySlug);
    if (featuredOnly) result = result.filter((p) => p.isFeatured);
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.description?.toLowerCase().includes(q) ||
          p.category?.name.toLowerCase().includes(q) ||
          p.tags?.toLowerCase().includes(q)
      );
    }
    if (sortBy === "name-asc") result.sort((a, b) => a.name.localeCompare(b.name));
    if (sortBy === "name-desc") result.sort((a, b) => b.name.localeCompare(a.name));
    if (sortBy === "featured") result.sort((a, b) => (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0));
    return result;
  }, [products, categorySlug, featuredOnly, search, sortBy]);

  const currentCategory = categories.find((c) => c.slug === categorySlug);

  return (
    <div style={{ backgroundColor: c.background }} className="min-h-screen">
      {/* Header */}
      <div style={{ backgroundColor: c.surface, borderBottom: `1px solid ${c.border}` }} className="sticky top-[57px] z-40 px-4 py-3">
        <div className="max-w-6xl mx-auto space-y-3">
          <div
            style={{ backgroundColor: c.surfaceAlt, borderRadius: theme.borderRadius, border: `1px solid ${c.border}` }}
            className="flex items-center gap-2 px-3 py-2"
          >
            <Search size={16} style={{ color: c.textMuted }} />
            <input
              type="text"
              placeholder="Search vegetables..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={{ color: c.text, backgroundColor: "transparent", fontFamily: theme.fonts.body }}
              className="flex-1 text-sm outline-none placeholder:opacity-50"
            />
          </div>

          <CategoryScroll categories={categories} activeSlug={categorySlug} />

          <div className="flex items-center justify-between">
            <p style={{ color: c.textMuted }} className="text-xs">
              {filtered.length} products
              {currentCategory ? ` in ${currentCategory.name}` : ""}
              {featuredOnly ? " (Featured)" : ""}
            </p>
            <div className="flex items-center gap-2">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                style={{
                  backgroundColor: c.surfaceAlt,
                  color: c.text,
                  border: `1px solid ${c.border}`,
                  borderRadius: theme.borderRadius,
                  fontFamily: theme.fonts.body,
                }}
                className="text-xs px-2 py-1.5 outline-none"
              >
                <option value="default">Default</option>
                <option value="name-asc">A–Z</option>
                <option value="name-desc">Z–A</option>
                <option value="featured">Featured First</option>
              </select>
              <div
                style={{ backgroundColor: c.surfaceAlt, borderRadius: theme.borderRadius, border: `1px solid ${c.border}` }}
                className="flex items-center"
              >
                <button
                  onClick={() => setView("grid")}
                  style={{ backgroundColor: view === "grid" ? c.primary : "transparent", color: view === "grid" ? "#fff" : c.textMuted, borderRadius: theme.borderRadius }}
                  className="p-1.5 transition-colors"
                >
                  <LayoutGrid size={15} />
                </button>
                <button
                  onClick={() => setView("list")}
                  style={{ backgroundColor: view === "list" ? c.primary : "transparent", color: view === "list" ? "#fff" : c.textMuted, borderRadius: theme.borderRadius }}
                  className="p-1.5 transition-colors"
                >
                  <List size={15} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Products */}
      <div className="max-w-6xl mx-auto px-4 py-5">
        {filtered.length === 0 ? (
          <div className="py-20 text-center">
            <span className="text-5xl block mb-4">🥬</span>
            <p style={{ color: c.text, fontFamily: theme.fonts.heading }} className="text-xl font-bold mb-2">
              No products found
            </p>
            <p style={{ color: c.textMuted }} className="text-sm">
              Try a different search or category
            </p>
          </div>
        ) : view === "grid" ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
            {filtered.map((p) => (
              <ProductCard key={p.id} product={p} variant="grid" />
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map((p) => (
              <ProductCard key={p.id} product={p} variant="list" />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default function ProductsClient({ products, categories }: { products: Product[]; categories: Category[] }) {
  return (
    <Suspense fallback={<div className="flex items-center justify-center h-64">Loading...</div>}>
      <ProductsInner products={products} categories={categories} />
    </Suspense>
  );
}
