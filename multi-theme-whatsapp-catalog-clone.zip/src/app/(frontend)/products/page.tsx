import React, { Suspense } from "react";
import { db } from "@/db";
import { products, categories } from "@/db/schema";
import { eq } from "drizzle-orm";
import ProductsClient from "./ProductsClient";

async function getData() {
  try {
    const cats = await db.select().from(categories).where(eq(categories.isActive, true));
    const prods = await db.select().from(products).where(eq(products.isActive, true));
    const catMap = Object.fromEntries(cats.map((c) => [c.id, c]));
    const mapped = prods
      .sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0))
      .map((p) => ({ ...p, category: p.categoryId ? catMap[p.categoryId] : null }));
    return { products: mapped, categories: cats.sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0)) };
  } catch {
    return { products: [], categories: [] };
  }
}

export default async function ProductsPage() {
  const { products, categories } = await getData();
  return (
    <Suspense fallback={<div className="flex items-center justify-center h-64 text-gray-400">Loading products...</div>}>
      <ProductsClient products={products} categories={categories} />
    </Suspense>
  );
}
