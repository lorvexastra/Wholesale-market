"use client";
import React, { useState, useEffect } from "react";
import { Plus, Pencil, Trash2, X, Check, GripVertical } from "lucide-react";

interface Banner {
  id: number;
  title: string;
  subtitle: string | null;
  imageUrl: string | null;
  linkUrl: string | null;
  isActive: boolean | null;
  sortOrder: number | null;
}

const empty = {
  title: "",
  subtitle: "",
  imageUrl: "",
  linkUrl: "",
  isActive: true,
  sortOrder: 0,
};

export default function AdminBannersPage() {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ ...empty });
  const [editId, setEditId] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);

  const fetchData = async () => {
    const r = await fetch("/api/admin/banners");
    const data = await r.json();
    setBanners(data.banners ?? []);
  };

  useEffect(() => { fetchData(); }, []);

  const openNew = () => { setForm({ ...empty }); setEditId(null); setShowForm(true); };
  const openEdit = (b: Banner) => {
    setForm({ title: b.title, subtitle: b.subtitle ?? "", imageUrl: b.imageUrl ?? "", linkUrl: b.linkUrl ?? "", isActive: b.isActive ?? true, sortOrder: b.sortOrder ?? 0 });
    setEditId(b.id);
    setShowForm(true);
  };

  const handleSave = async () => {
    setSaving(true);
    const payload = { ...form, imageUrl: form.imageUrl || null, linkUrl: form.linkUrl || null };
    try {
      if (editId) {
        await fetch("/api/admin/banners", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...payload, id: editId }) });
      } else {
        await fetch("/api/admin/banners", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      }
      await fetchData();
      setShowForm(false);
    } finally { setSaving(false); }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Delete this banner?")) return;
    await fetch(`/api/admin/banners?id=${id}`, { method: "DELETE" });
    await fetchData();
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-white">Hero Banners</h1>
          <p className="text-slate-400 text-sm">{banners.length} banners for homepage slider</p>
        </div>
        <button onClick={openNew} className="flex items-center gap-2 px-4 py-2.5 bg-green-600 hover:bg-green-500 text-white font-bold text-sm rounded-xl transition-all active:scale-95">
          <Plus size={16} /> Add Banner
        </button>
      </div>

      <div className="space-y-4">
        {banners.map((b) => (
          <div key={b.id} className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden flex gap-4 p-4">
            <div className="w-32 h-20 flex-shrink-0 rounded-xl overflow-hidden bg-slate-800">
              {b.imageUrl ? <img src={b.imageUrl} alt={b.title} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-2xl">🖼️</div>}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-white font-bold text-sm">{b.title}</p>
                  {b.subtitle && <p className="text-slate-400 text-xs mt-1 line-clamp-2">{b.subtitle}</p>}
                </div>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold flex-shrink-0 ${b.isActive ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}`}>
                  {b.isActive ? "Active" : "Hidden"}
                </span>
              </div>
              <div className="flex gap-2 mt-3">
                <button onClick={() => openEdit(b)} className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-lg transition-colors">
                  <Pencil size={12} /> Edit
                </button>
                <button onClick={() => handleDelete(b.id)} className="flex items-center gap-1.5 px-3 py-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs font-semibold rounded-lg transition-colors">
                  <Trash2 size={12} /> Delete
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70">
          <div className="w-full max-w-md bg-slate-900 rounded-2xl border border-slate-700 flex flex-col max-h-[90vh]">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800">
              <h3 className="font-bold text-white">{editId ? "Edit Banner" : "New Banner"}</h3>
              <button onClick={() => setShowForm(false)} className="text-slate-400 hover:text-white"><X size={20} /></button>
            </div>
            <div className="p-5 space-y-4 overflow-y-auto">
              {[
                { label: "Title *", key: "title", type: "text" },
                { label: "Subtitle", key: "subtitle", type: "text" },
                { label: "Image URL", key: "imageUrl", type: "url" },
                { label: "Link URL", key: "linkUrl", type: "url" },
                { label: "Sort Order", key: "sortOrder", type: "number" },
              ].map(({ label, key, type }) => (
                <div key={key}>
                  <label className="text-slate-300 text-xs font-semibold mb-1 block uppercase tracking-wide">{label}</label>
                  <input
                    type={type}
                    value={(form as Record<string, unknown>)[key] as string ?? ""}
                    onChange={(e) => setForm((f) => ({ ...f, [key]: type === "number" ? parseInt(e.target.value) || 0 : e.target.value }))}
                    className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-3 py-2.5 text-sm outline-none focus:border-green-500"
                  />
                </div>
              ))}
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={form.isActive} onChange={(e) => setForm((f) => ({ ...f, isActive: e.target.checked }))} className="w-4 h-4 accent-green-500" />
                <span className="text-slate-300 text-sm">Active</span>
              </label>
              {form.imageUrl && (
                <div>
                  <p className="text-slate-400 text-xs mb-2">Preview:</p>
                  <img src={form.imageUrl} alt="Banner preview" className="w-full h-32 object-cover rounded-xl" />
                </div>
              )}
            </div>
            <div className="px-5 py-4 border-t border-slate-800 flex gap-3">
              <button onClick={handleSave} disabled={saving || !form.title}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-green-600 hover:bg-green-500 disabled:opacity-60 text-white font-bold text-sm rounded-xl">
                {saving ? "Saving..." : <><Check size={16} /> Save Banner</>}
              </button>
              <button onClick={() => setShowForm(false)} className="px-4 py-2.5 bg-slate-800 text-slate-300 font-semibold text-sm rounded-xl">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
