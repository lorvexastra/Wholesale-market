"use client";
import React, { useState, useEffect } from "react";
import { Plus, Pencil, X, Check } from "lucide-react";

interface Category {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  imageUrl: string | null;
  isActive: boolean | null;
  sortOrder: number | null;
}

const empty = {
  name: "",
  slug: "",
  description: "",
  imageUrl: "",
  isActive: true,
  sortOrder: 0,
};

export default function AdminCategoriesPage() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ ...empty });
  const [editId, setEditId] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    setLoading(true);
    const r = await fetch("/api/admin/categories");
    const data = await r.json();
    setCategories(data.categories ?? []);
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const openNew = () => {
    setForm({ ...empty });
    setEditId(null);
    setShowForm(true);
  };

  const openEdit = (c: Category) => {
    setForm({
      name: c.name,
      slug: c.slug,
      description: c.description ?? "",
      imageUrl: c.imageUrl ?? "",
      isActive: c.isActive ?? true,
      sortOrder: c.sortOrder ?? 0,
    });
    setEditId(c.id);
    setShowForm(true);
  };

  const handleSave = async () => {
    setSaving(true);
    const slug = form.slug || form.name.toLowerCase().replace(/[^a-z0-9]+/g, "-");
    const payload = { ...form, slug, imageUrl: form.imageUrl || null };
    try {
      if (editId) {
        await fetch(`/api/admin/categories/${editId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      } else {
        await fetch("/api/admin/categories", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      }
      await fetchData();
      setShowForm(false);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-white">Categories</h1>
          <p className="text-slate-400 text-sm">{categories.length} categories</p>
        </div>
        <button onClick={openNew} className="flex items-center gap-2 px-4 py-2.5 bg-green-600 hover:bg-green-500 text-white font-bold text-sm rounded-xl transition-all active:scale-95">
          <Plus size={16} /> Add Category
        </button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? (
          <p className="text-slate-400">Loading...</p>
        ) : categories.map((cat) => (
          <div key={cat.id} className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
            {cat.imageUrl ? (
              <img src={cat.imageUrl} alt={cat.name} className="w-full h-36 object-cover" />
            ) : (
              <div className="w-full h-36 bg-slate-800 flex items-center justify-center text-5xl">🥗</div>
            )}
            <div className="p-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="text-white font-bold">{cat.name}</h3>
                  <p className="text-slate-400 text-xs">{cat.slug}</p>
                  {cat.description && <p className="text-slate-400 text-xs mt-1 line-clamp-2">{cat.description}</p>}
                </div>
                <div className="flex gap-1.5 flex-shrink-0">
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${cat.isActive ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}`}>
                    {cat.isActive ? "Active" : "Hidden"}
                  </span>
                </div>
              </div>
              <button onClick={() => openEdit(cat)} className="mt-3 w-full flex items-center justify-center gap-1.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl transition-colors">
                <Pencil size={12} /> Edit
              </button>
            </div>
          </div>
        ))}
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70">
          <div className="w-full max-w-md bg-slate-900 rounded-2xl border border-slate-700 flex flex-col max-h-[90vh]">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800">
              <h3 className="font-bold text-white">{editId ? "Edit Category" : "New Category"}</h3>
              <button onClick={() => setShowForm(false)} className="text-slate-400 hover:text-white"><X size={20} /></button>
            </div>
            <div className="p-5 space-y-4 overflow-y-auto">
              {[
                { label: "Category Name *", key: "name", type: "text" },
                { label: "Slug (auto-generated)", key: "slug", type: "text" },
                { label: "Image URL", key: "imageUrl", type: "url" },
                { label: "Sort Order", key: "sortOrder", type: "number" },
              ].map(({ label, key, type }) => (
                <div key={key}>
                  <label className="text-slate-300 text-xs font-semibold mb-1 block uppercase tracking-wide">{label}</label>
                  <input
                    type={type}
                    value={(form as Record<string, unknown>)[key] as string ?? ""}
                    onChange={(e) => setForm((f) => ({ ...f, [key]: type === "number" ? parseInt(e.target.value) || 0 : e.target.value }))}
                    className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-3 py-2.5 text-sm outline-none focus:border-green-500"
                  />
                </div>
              ))}
              <div>
                <label className="text-slate-300 text-xs font-semibold mb-1 block uppercase tracking-wide">Description</label>
                <textarea rows={2} value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-3 py-2.5 text-sm outline-none focus:border-green-500 resize-none" />
              </div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={form.isActive} onChange={(e) => setForm((f) => ({ ...f, isActive: e.target.checked }))} className="w-4 h-4 accent-green-500" />
                <span className="text-slate-300 text-sm">Active</span>
              </label>
            </div>
            <div className="px-5 py-4 border-t border-slate-800 flex gap-3">
              <button onClick={handleSave} disabled={saving || !form.name}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-green-600 hover:bg-green-500 disabled:opacity-60 text-white font-bold text-sm rounded-xl">
                {saving ? "Saving..." : <><Check size={16} /> Save</>}
              </button>
              <button onClick={() => setShowForm(false)} className="px-4 py-2.5 bg-slate-800 text-slate-300 font-semibold text-sm rounded-xl">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
