"use client";
import React, { useState, useEffect } from "react";
import { Save, Check } from "lucide-react";

interface FooterData {
  companyName: string;
  companyDescription: string;
  address: string;
  phone: string;
  email: string;
  whatsappNumber: string;
  instagramUrl: string;
  facebookUrl: string;
  supportHours: string;
}

export default function AdminFooterPage() {
  const [form, setForm] = useState<FooterData>({
    companyName: "Sardar Vegetable Market",
    companyDescription: "Trusted wholesale vegetables supplier in Surat. Fresh farm produce delivered directly to your business.",
    address: "Sardar Vegetable Market, Surat, Gujarat - 395003",
    phone: "+91 98765 43210",
    email: "info@sardarvegetablemarket.in",
    whatsappNumber: "919876543210",
    instagramUrl: "https://instagram.com/sardarvegetablemarket",
    facebookUrl: "https://facebook.com/sardarvegetablemarket",
    supportHours: "Mon - Sun: 4:00 AM – 10:00 AM",
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then((data) => {
        if (data.footer) {
          setForm({
            companyName: data.footer.companyName ?? form.companyName,
            companyDescription: data.footer.companyDescription ?? form.companyDescription,
            address: data.footer.address ?? form.address,
            phone: data.footer.phone ?? form.phone,
            email: data.footer.email ?? form.email,
            whatsappNumber: data.footer.whatsappNumber ?? form.whatsappNumber,
            instagramUrl: data.footer.instagramUrl ?? form.instagramUrl,
            facebookUrl: data.footer.facebookUrl ?? form.facebookUrl,
            supportHours: data.footer.supportHours ?? form.supportHours,
          });
        }
        setLoading(false);
      });
  }, []);

  const handleChange = (field: keyof FooterData, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await fetch("/api/admin/footer", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } finally {
      setSaving(false);
    }
  };

  const fields = [
    { key: "companyName", label: "Company Name", type: "text", note: "Shown in navbar & footer" },
    { key: "companyDescription", label: "Company Description", type: "textarea", note: "Brief tagline in footer" },
    { key: "whatsappNumber", label: "WhatsApp Number", type: "text", note: "With country code, no + or spaces (e.g. 919876543210). This links ALL enquiry buttons." },
    { key: "phone", label: "Phone Number", type: "text", note: "Shown in contact page and footer" },
    { key: "email", label: "Email Address", type: "email", note: "Shown in contact page" },
    { key: "address", label: "Address", type: "textarea", note: "Full address shown in footer & contact" },
    { key: "supportHours", label: "Support / Supply Hours", type: "text", note: "e.g. Mon - Sun: 4:00 AM – 10:00 AM" },
    { key: "instagramUrl", label: "Instagram URL", type: "url", note: "Optional" },
    { key: "facebookUrl", label: "Facebook URL", type: "url", note: "Optional" },
  ] as const;

  if (loading) {
    return <div className="flex items-center justify-center h-64 text-slate-400">Loading...</div>;
  }

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold text-white">Footer & Contact Settings</h1>
        <p className="text-slate-400 text-sm mt-1">Update contact details, WhatsApp number, and footer information.</p>
      </div>

      {/* WhatsApp Highlight */}
      <div className="bg-green-900/30 border border-green-700/50 rounded-2xl p-4">
        <p className="text-green-400 font-bold text-sm mb-1">📱 WhatsApp Number (Important!)</p>
        <p className="text-green-300/70 text-xs">
          The WhatsApp number below links to <strong>ALL product enquiry buttons</strong> on the frontend.
          When customers click &apos;Enquire&apos; on any product, they&apos;ll message this number.
        </p>
      </div>

      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-5">
        {fields.map(({ key, label, type, note }) => (
          <div key={key}>
            <label className="text-slate-300 text-sm font-semibold mb-1.5 block">{label}</label>
            {type === "textarea" ? (
              <textarea
                rows={3}
                value={form[key] || ""}
                onChange={(e) => handleChange(key, e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 text-white placeholder:text-slate-500 rounded-xl px-4 py-3 text-sm outline-none focus:border-green-500 transition-colors resize-none"
              />
            ) : (
              <input
                type={type}
                value={form[key] || ""}
                onChange={(e) => handleChange(key, e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 text-white placeholder:text-slate-500 rounded-xl px-4 py-3 text-sm outline-none focus:border-green-500 transition-colors"
              />
            )}
            <p className="text-slate-500 text-xs mt-1">{note}</p>
          </div>
        ))}
      </div>

      <button
        onClick={handleSave}
        disabled={saving}
        className="flex items-center gap-2 px-6 py-3 bg-green-600 hover:bg-green-500 disabled:opacity-60 text-white font-bold text-sm rounded-xl transition-all active:scale-95"
      >
        {saved ? <Check size={18} /> : <Save size={18} />}
        {saving ? "Saving..." : saved ? "Saved!" : "Save Settings"}
      </button>
    </div>
  );
}
