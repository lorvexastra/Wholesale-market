"use client";
import React, { useEffect, useState } from "react";
import Link from "next/link";
import { Package, Tag, Image, Palette, FileText, ArrowRight, Leaf } from "lucide-react";

interface Stats {
  products: number;
  categories: number;
  banners: number;
  theme: string;
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<Stats>({ products: 0, categories: 0, banners: 0, theme: "theme1" });
  const [seeding, setSeeding] = useState(false);
  const [seedMsg, setSeedMsg] = useState("");

  useEffect(() => {
    Promise.all([
      fetch("/api/admin/products").then((r) => r.json()),
      fetch("/api/admin/categories").then((r) => r.json()),
      fetch("/api/admin/banners").then((r) => r.json()),
      fetch("/api/settings").then((r) => r.json()),
    ]).then(([prods, cats, bans, settings]) => {
      setStats({
        products: prods.products?.length ?? 0,
        categories: cats.categories?.length ?? 0,
        banners: bans.banners?.length ?? 0,
        theme: settings.theme?.activeTheme ?? "theme1",
      });
    });
  }, []);

  const handleSeed = async () => {
    setSeeding(true);
    setSeedMsg("");
    try {
      const r = await fetch("/api/seed", { method: "POST" });
      const data = await r.json();
      setSeedMsg(data.message ?? "Done!");
      // Refresh stats
      const prods = await fetch("/api/admin/products").then((r) => r.json());
      const cats = await fetch("/api/admin/categories").then((r) => r.json());
      setStats((s) => ({ ...s, products: prods.products?.length ?? 0, categories: cats.categories?.length ?? 0 }));
    } catch (e) {
      setSeedMsg("Error seeding data");
    } finally {
      setSeeding(false);
    }
  };

  const cards = [
    { href: "/admin/products", icon: <Package size={22} />, label: "Products", value: stats.products, bg: "linear-gradient(135deg, #2563eb, #1e40af)" },
    { href: "/admin/categories", icon: <Tag size={22} />, label: "Categories", value: stats.categories, bg: "linear-gradient(135deg, #9333ea, #6b21a8)" },
    { href: "/admin/banners", icon: <Image size={22} />, label: "Banners", value: stats.banners, bg: "linear-gradient(135deg, #ea580c, #9a3412)" },
    { href: "/admin/theme", icon: <Palette size={22} />, label: "Active Theme", value: stats.theme, bg: "linear-gradient(135deg, #16a34a, #14532d)" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Dashboard</h1>
        <p className="text-slate-400 text-sm mt-1">Manage your vegetable market website</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((card) => (
          <Link
            key={card.href}
            href={card.href}
            className="group relative overflow-hidden rounded-2xl p-5 flex flex-col gap-3 hover:scale-105 transition-transform duration-200"
            style={{ background: card.bg }}
          >
            <div className="absolute inset-0 rounded-2xl" style={{ background: card.bg }} />
            <div className="relative z-10">
              <div className="text-white/70 mb-2">{card.icon}</div>
              <p className="text-3xl font-bold text-white">{card.value}</p>
              <p className="text-white/80 text-xs mt-1">{card.label}</p>
            </div>
            <ArrowRight size={14} className="absolute bottom-4 right-4 text-white/50 group-hover:text-white transition-colors z-10" />
          </Link>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5">
          <h2 className="font-bold text-white mb-4">Quick Actions</h2>
          <div className="space-y-2">
            {[
              { href: "/admin/products", label: "➕ Add New Product", desc: "Add vegetables to catalogue" },
              { href: "/admin/theme", label: "🎨 Change Theme", desc: "Switch website theme & logo" },
              { href: "/admin/footer", label: "📞 Update Contact Info", desc: "Edit footer & WhatsApp number" },
              { href: "/admin/banners", label: "🖼️ Manage Banners", desc: "Update hero slider banners" },
            ].map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="flex items-center gap-3 p-3 rounded-xl bg-slate-800 hover:bg-slate-700 transition-colors group"
              >
                <div className="flex-1">
                  <p className="text-sm font-semibold text-white">{item.label}</p>
                  <p className="text-xs text-slate-400">{item.desc}</p>
                </div>
                <ArrowRight size={14} className="text-slate-500 group-hover:text-white transition-colors" />
              </Link>
            ))}
          </div>
        </div>

        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5">
          <h2 className="font-bold text-white mb-2">Database Setup</h2>
          <p className="text-slate-400 text-xs mb-4">
            First time? Seed the database with default vegetables, categories, and banners from Sardar Vegetable Market.
          </p>
          <button
            onClick={handleSeed}
            disabled={seeding}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-green-600 hover:bg-green-500 text-white font-bold text-sm rounded-xl transition-all disabled:opacity-60"
          >
            <Leaf size={16} />
            {seeding ? "Seeding..." : "Seed Default Data"}
          </button>
          {seedMsg && (
            <p className="text-green-400 text-xs mt-2 text-center">{seedMsg}</p>
          )}

          <div className="mt-5 pt-4 border-t border-slate-800">
            <h3 className="text-sm font-semibold text-white mb-2">View Website</h3>
            <div className="flex gap-2 flex-wrap">
              {["/", "/products", "/about", "/contact"].map((href) => (
                <Link
                  key={href}
                  href={href}
                  target="_blank"
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-lg transition-colors"
                >
                  {href === "/" ? "Home" : href.replace("/", "").charAt(0).toUpperCase() + href.replace("/", "").slice(1)}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
