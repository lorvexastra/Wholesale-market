"use client";
import React, { useState, useEffect } from "react";
import { Plus, Pencil, Trash2, Search, Check, X } from "lucide-react";

interface Category {
  id: number;
  name: string;
  slug: string;
}

interface Product {
  id: number;
  name: string;
  unit: string | null;
  priceLabel: string | null;
  imageUrl: string | null;
  description: string | null;
  tags: string | null;
  isFeatured: boolean | null;
  isActive: boolean | null;
  sortOrder: number | null;
  categoryId: number | null;
  category?: Category | null;
}

const emptyProduct = {
  name: "",
  unit: "kg",
  priceLabel: "Best Price",
  imageUrl: "",
  description: "",
  tags: "",
  isFeatured: false,
  isActive: true,
  sortOrder: 0,
  categoryId: null as number | null,
};

export default function AdminProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState({ ...emptyProduct });
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    const r = await fetch("/api/admin/products");
    const data = await r.json();
    setProducts(data.products ?? []);
    setCategories(data.categories ?? []);
    setLoading(false);
  };

  const filtered = products.filter(
    (p) =>
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.category?.name.toLowerCase().includes(search.toLowerCase())
  );

  const openNew = () => {
    setForm({ ...emptyProduct });
    setEditId(null);
    setShowForm(true);
  };

  const openEdit = (p: Product) => {
    setForm({
      name: p.name,
      unit: p.unit ?? "kg",
      priceLabel: p.priceLabel ?? "Best Price",
      imageUrl: p.imageUrl ?? "",
      description: p.description ?? "",
      tags: p.tags ?? "",
      isFeatured: p.isFeatured ?? false,
      isActive: p.isActive ?? true,
      sortOrder: p.sortOrder ?? 0,
      categoryId: p.categoryId,
    });
    setEditId(p.id);
    setShowForm(true);
  };

  const handleSave = async () => {
    setSaving(true);
    const payload = {
      ...form,
      slug: form.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, ""),
      imageUrl: form.imageUrl || null,
    };
    try {
      if (editId) {
        await fetch(`/api/admin/products/${editId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      } else {
        await fetch("/api/admin/products", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      }
      await fetchData();
      setShowForm(false);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Delete this product?")) return;
    await fetch(`/api/admin/products/${id}`, { method: "DELETE" });
    await fetchData();
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-white">Products</h1>
          <p className="text-slate-400 text-sm">{products.length} products total</p>
        </div>
        <button
          onClick={openNew}
          className="flex items-center gap-2 px-4 py-2.5 bg-green-600 hover:bg-green-500 text-white font-bold text-sm rounded-xl transition-all active:scale-95"
        >
          <Plus size={16} /> Add Product
        </button>
      </div>

      {/* Search */}
      <div className="flex items-center gap-2 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5">
        <Search size={16} className="text-slate-400" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search products..."
          className="flex-1 bg-transparent text-white text-sm outline-none placeholder:text-slate-500"
        />
      </div>

      {/* Table */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-slate-400">Loading...</div>
        ) : filtered.length === 0 ? (
          <div className="p-8 text-center text-slate-400">No products found</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-800">
                  <th className="text-left px-4 py-3 text-slate-400 font-semibold text-xs uppercase tracking-wide">Product</th>
                  <th className="text-left px-4 py-3 text-slate-400 font-semibold text-xs uppercase tracking-wide hidden sm:table-cell">Category</th>
                  <th className="text-left px-4 py-3 text-slate-400 font-semibold text-xs uppercase tracking-wide hidden md:table-cell">Unit</th>
                  <th className="text-left px-4 py-3 text-slate-400 font-semibold text-xs uppercase tracking-wide hidden md:table-cell">Featured</th>
                  <th className="text-left px-4 py-3 text-slate-400 font-semibold text-xs uppercase tracking-wide hidden md:table-cell">Active</th>
                  <th className="text-right px-4 py-3 text-slate-400 font-semibold text-xs uppercase tracking-wide">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((p, i) => (
                  <tr key={p.id} className={`border-b border-slate-800/50 hover:bg-slate-800/50 ${i % 2 === 0 ? "" : "bg-slate-900/50"}`}>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        {p.imageUrl ? (
                          <img src={p.imageUrl} alt={p.name} className="w-10 h-10 rounded-lg object-cover flex-shrink-0" />
                        ) : (
                          <div className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center text-lg flex-shrink-0">🥬</div>
                        )}
                        <div>
                          <p className="text-white font-semibold">{p.name}</p>
                          <p className="text-slate-400 text-xs sm:hidden">{p.category?.name}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-slate-300 text-xs hidden sm:table-cell">{p.category?.name ?? "—"}</td>
                    <td className="px-4 py-3 text-slate-300 text-xs hidden md:table-cell">{p.unit}</td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      {p.isFeatured ? (
                        <span className="px-2 py-0.5 bg-amber-500/20 text-amber-400 rounded-full text-[10px] font-bold">⭐ Yes</span>
                      ) : (
                        <span className="text-slate-500 text-xs">No</span>
                      )}
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      {p.isActive ? (
                        <span className="px-2 py-0.5 bg-green-500/20 text-green-400 rounded-full text-[10px] font-bold">Active</span>
                      ) : (
                        <span className="px-2 py-0.5 bg-red-500/20 text-red-400 rounded-full text-[10px] font-bold">Inactive</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button onClick={() => openEdit(p)} className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-colors">
                          <Pencil size={14} />
                        </button>
                        <button onClick={() => handleDelete(p.id)} className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-colors">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70">
          <div className="w-full max-w-lg bg-slate-900 rounded-2xl border border-slate-700 flex flex-col max-h-[90vh]">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800">
              <h3 className="font-bold text-white">{editId ? "Edit Product" : "Add New Product"}</h3>
              <button onClick={() => setShowForm(false)} className="text-slate-400 hover:text-white">
                <X size={20} />
              </button>
            </div>
            <div className="overflow-y-auto p-5 space-y-4 flex-1">
              {[
                { label: "Product Name *", key: "name", type: "text" },
                { label: "Image URL", key: "imageUrl", type: "url" },
                { label: "Price Label", key: "priceLabel", type: "text" },
                { label: "Unit (kg, bunch, piece)", key: "unit", type: "text" },
                { label: "Tags (comma separated)", key: "tags", type: "text" },
                { label: "Sort Order", key: "sortOrder", type: "number" },
              ].map(({ label, key, type }) => (
                <div key={key}>
                  <label className="text-slate-300 text-xs font-semibold mb-1 block uppercase tracking-wide">{label}</label>
                  <input
                    type={type}
                    value={(form as Record<string, unknown>)[key] as string ?? ""}
                    onChange={(e) => setForm((f) => ({ ...f, [key]: type === "number" ? parseInt(e.target.value) || 0 : e.target.value }))}
                    className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-3 py-2.5 text-sm outline-none focus:border-green-500"
                  />
                </div>
              ))}

              <div>
                <label className="text-slate-300 text-xs font-semibold mb-1 block uppercase tracking-wide">Description</label>
                <textarea
                  rows={3}
                  value={form.description}
                  onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-3 py-2.5 text-sm outline-none focus:border-green-500 resize-none"
                />
              </div>

              <div>
                <label className="text-slate-300 text-xs font-semibold mb-1 block uppercase tracking-wide">Category</label>
                <select
                  value={form.categoryId ?? ""}
                  onChange={(e) => setForm((f) => ({ ...f, categoryId: e.target.value ? parseInt(e.target.value) : null }))}
                  className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-3 py-2.5 text-sm outline-none focus:border-green-500"
                >
                  <option value="">No category</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div className="flex gap-6">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.isFeatured}
                    onChange={(e) => setForm((f) => ({ ...f, isFeatured: e.target.checked }))}
                    className="w-4 h-4 accent-green-500"
                  />
                  <span className="text-slate-300 text-sm">Featured</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.isActive}
                    onChange={(e) => setForm((f) => ({ ...f, isActive: e.target.checked }))}
                    className="w-4 h-4 accent-green-500"
                  />
                  <span className="text-slate-300 text-sm">Active</span>
                </label>
              </div>
            </div>
            <div className="px-5 py-4 border-t border-slate-800 flex gap-3">
              <button
                onClick={handleSave}
                disabled={saving || !form.name}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-green-600 hover:bg-green-500 disabled:opacity-60 text-white font-bold text-sm rounded-xl transition-all"
              >
                {saving ? "Saving..." : <><Check size={16} /> {editId ? "Update" : "Add"} Product</>}
              </button>
              <button onClick={() => setShowForm(false)} className="px-4 py-2.5 bg-slate-800 text-slate-300 font-semibold text-sm rounded-xl hover:bg-slate-700 transition-colors">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
