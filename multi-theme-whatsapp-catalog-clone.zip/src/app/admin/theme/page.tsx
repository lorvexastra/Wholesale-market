"use client";
import React, { useState, useEffect } from "react";
import { themes, ThemeId } from "@/lib/themes";
import { Check, Eye, Save, Leaf } from "lucide-react";
import Link from "next/link";

export default function AdminThemePage() {
  const [activeTheme, setActiveTheme] = useState<ThemeId>("theme1");
  const [previewTheme, setPreviewTheme] = useState<ThemeId | null>(null);
  const [brandName, setBrandName] = useState("Sardar Vegetable Market");
  const [logoUrl, setLogoUrl] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then((data) => {
        if (data.theme) {
          setActiveTheme(data.theme.activeTheme ?? "theme1");
          setBrandName(data.theme.brandName ?? "Sardar Vegetable Market");
          setLogoUrl(data.theme.logoUrl ?? "");
        }
        setLoading(false);
      });
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      await fetch("/api/admin/theme", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          activeTheme,
          brandName,
          logoUrl: logoUrl || null,
        }),
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } finally {
      setSaving(false);
    }
  };

  const displayTheme = previewTheme ?? activeTheme;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-slate-400">Loading...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <h1 className="text-2xl font-bold text-white">Theme & Branding</h1>
        <p className="text-slate-400 text-sm mt-1">Choose a theme and customize branding. Changes are live on the frontend.</p>
      </div>

      {/* Theme Selection */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5">
        <h2 className="font-bold text-white mb-1">Choose Theme</h2>
        <p className="text-slate-400 text-xs mb-5">5 unique themes with different aesthetics, fonts & color palettes</p>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Object.values(themes).map((theme) => {
            const isActive = activeTheme === theme.id;
            const isPreviewing = previewTheme === theme.id;

            return (
              <div
                key={theme.id}
                className={`relative rounded-2xl border-2 overflow-hidden cursor-pointer transition-all duration-200 ${
                  isActive
                    ? "border-green-500 shadow-lg shadow-green-900/40"
                    : "border-slate-700 hover:border-slate-500"
                }`}
                onClick={() => setActiveTheme(theme.id as ThemeId)}
              >
                {/* Theme preview gradient */}
                <div className={`h-20 ${theme.preview}`} />

                {/* Font preview strip */}
                <div
                  style={{ backgroundColor: theme.colors.surface, borderTop: `2px solid ${theme.colors.primary}` }}
                  className="px-4 py-3"
                >
                  <p
                    style={{ fontFamily: theme.fonts.heading, color: theme.colors.text, fontSize: 15 }}
                    className="font-bold leading-tight"
                  >
                    {theme.name}
                  </p>
                  <p
                    style={{ fontFamily: theme.fonts.body, color: theme.colors.textMuted, fontSize: 11 }}
                    className="mt-0.5"
                  >
                    {theme.description}
                  </p>
                  <div className="flex gap-1.5 mt-2">
                    <div style={{ backgroundColor: theme.colors.primary }} className="w-4 h-4 rounded-full" />
                    <div style={{ backgroundColor: theme.colors.secondary }} className="w-4 h-4 rounded-full" />
                    <div style={{ backgroundColor: theme.colors.accent }} className="w-4 h-4 rounded-full" />
                    <div style={{ backgroundColor: theme.colors.background }} className="w-4 h-4 rounded-full border border-gray-200" />
                  </div>
                  <p style={{ color: theme.colors.textMuted, fontSize: 10 }} className="mt-2 opacity-70">
                    Heading: {theme.fonts.heading.split(",")[0].replace(/'/g, "")}
                  </p>
                  <p style={{ color: theme.colors.textMuted, fontSize: 10 }} className="opacity-70">
                    Body: {theme.fonts.body.split(",")[0].replace(/'/g, "")}
                  </p>
                </div>

                {/* Badges */}
                {isActive && (
                  <div className="absolute top-2 left-2 flex items-center gap-1 bg-green-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                    <Check size={10} /> ACTIVE
                  </div>
                )}

                {/* Action buttons */}
                <div className="absolute top-2 right-2 flex gap-1">
                  <Link
                    href={`/admin/theme/preview?theme=${theme.id}`}
                    target="_blank"
                    onClick={(e) => e.stopPropagation()}
                    className="flex items-center gap-1 bg-black/40 hover:bg-black/60 text-white text-[10px] font-bold px-2 py-1 rounded-full backdrop-blur-sm transition-colors"
                  >
                    <Eye size={10} /> Preview
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Branding */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5">
        <h2 className="font-bold text-white mb-1">Brand Settings</h2>
        <p className="text-slate-400 text-xs mb-5">These apply across all themes</p>

        <div className="space-y-4 max-w-md">
          <div>
            <label className="text-slate-300 text-sm font-semibold mb-2 block">Brand / Store Name</label>
            <input
              type="text"
              value={brandName}
              onChange={(e) => setBrandName(e.target.value)}
              placeholder="e.g. Sardar Vegetable Market"
              className="w-full bg-slate-800 border border-slate-700 text-white placeholder:text-slate-500 rounded-xl px-4 py-3 text-sm outline-none focus:border-green-500 transition-colors"
            />
            <p className="text-slate-500 text-xs mt-1">Shown in navbar and footer</p>
          </div>

          <div>
            <label className="text-slate-300 text-sm font-semibold mb-2 block">Logo URL</label>
            <input
              type="url"
              value={logoUrl}
              onChange={(e) => setLogoUrl(e.target.value)}
              placeholder="https://example.com/logo.png"
              className="w-full bg-slate-800 border border-slate-700 text-white placeholder:text-slate-500 rounded-xl px-4 py-3 text-sm outline-none focus:border-green-500 transition-colors"
            />
            <p className="text-slate-500 text-xs mt-1">Leave empty to use default leaf icon</p>
          </div>

          {/* Logo Preview */}
          <div className="flex items-center gap-3 p-3 bg-slate-800 rounded-xl">
            {logoUrl ? (
              <img src={logoUrl} alt="Logo preview" className="h-10 w-10 rounded-xl object-cover border border-slate-600" />
            ) : (
              <div className="h-10 w-10 bg-gradient-to-br from-green-500 to-emerald-700 rounded-xl flex items-center justify-center">
                <Leaf size={18} color="#fff" />
              </div>
            )}
            <div>
              <p className="text-white text-sm font-semibold">{brandName || "Store Name"}</p>
              <p className="text-slate-400 text-xs">Logo preview</p>
            </div>
          </div>
        </div>
      </div>

      {/* Save Button */}
      <button
        onClick={handleSave}
        disabled={saving}
        className="flex items-center gap-2 px-6 py-3 bg-green-600 hover:bg-green-500 disabled:opacity-60 text-white font-bold text-sm rounded-xl transition-all active:scale-95"
      >
        {saved ? <Check size={18} /> : <Save size={18} />}
        {saving ? "Saving..." : saved ? "Saved!" : "Save Theme & Branding"}
      </button>

      <p className="text-slate-500 text-xs">
        ℹ️ After saving, the frontend will reflect the new theme immediately. Visitors will see the theme you selected.
      </p>
    </div>
  );
}
