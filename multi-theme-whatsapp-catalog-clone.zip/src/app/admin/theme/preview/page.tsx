"use client";
import React, { useEffect, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { themes, ThemeId, getTheme } from "@/lib/themes";
import { ArrowLeft, ShoppingCart, Leaf, MessageCircle } from "lucide-react";
import Link from "next/link";

function ThemePreviewContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const themeId = (searchParams.get("theme") ?? "theme1") as ThemeId;
  const theme = getTheme(themeId);
  const c = theme.colors;

  useEffect(() => {
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = theme.fonts.googleFonts;
    document.head.appendChild(link);
    return () => { try { document.head.removeChild(link); } catch {} };
  }, [theme.fonts.googleFonts]);

  const sampleProducts = [
    { name: "Spinach (Palak)", cat: "Leafy Vegetables", emoji: "🥬", featured: true },
    { name: "Tomato", cat: "Root Vegetables", emoji: "🍅", featured: false },
    { name: "Broccoli", cat: "Exotic Vegetables", emoji: "🥦", featured: true },
    { name: "Capsicum", cat: "Fruits & Pods", emoji: "🫑", featured: false },
  ];

  return (
    <div style={{ fontFamily: theme.fonts.body, backgroundColor: c.background, minHeight: "100vh" }}>
      {/* Preview Banner */}
      <div className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-4 py-2 text-xs font-bold text-white"
        style={{ backgroundColor: "#1e293b", borderBottom: "2px solid #22d3ee" }}>
        <Link href="/admin/theme" className="flex items-center gap-1 hover:opacity-80">
          <ArrowLeft size={14} /> Back to Admin
        </Link>
        <span className="opacity-80">PREVIEW: {theme.name}</span>
        <span className="text-[10px] opacity-60">Not saved yet</span>
      </div>

      <div className="pt-9">
        {/* Navbar */}
        <nav style={{ backgroundColor: c.navBg, borderBottom: `1px solid ${c.border}` }} className="px-5 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div style={{ background: `linear-gradient(135deg, ${c.primary}, ${c.accent})` }} className="h-8 w-8 rounded-xl flex items-center justify-center">
              <Leaf size={15} color="#fff" />
            </div>
            <span style={{ color: c.navText, fontFamily: theme.fonts.heading }} className="font-bold text-sm">
              Sardar Vegetable Market
            </span>
          </div>
          <div className="flex items-center gap-3">
            <span style={{ color: c.navText }} className="text-xs hidden sm:block">Home</span>
            <span style={{ color: c.navText }} className="text-xs hidden sm:block">Products</span>
            <div style={{ backgroundColor: c.btnPrimary, color: c.btnPrimaryText, borderRadius: theme.borderRadius }}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold">
              <ShoppingCart size={13} />
              Cart (2)
            </div>
          </div>
        </nav>

        {/* Hero */}
        <div style={{ background: theme.colors.heroBg }} className="px-6 py-14 text-center">
          <div className="inline-block px-3 py-1 rounded-full text-xs font-semibold mb-3"
            style={{ backgroundColor: "rgba(255,255,255,0.2)", color: "#fff" }}>
            🌿 Wholesale Vegetable Supplier
          </div>
          <h1 style={{ fontFamily: theme.fonts.heading, color: "#fff" }} className="text-3xl font-bold mb-3">
            Fresh Vegetables Direct From Farm
          </h1>
          <p className="text-white/80 text-sm mb-5">Wholesale supplier for hotels, restaurants & caterers in Surat</p>
          <div className="flex gap-3 justify-center">
            <button style={{ backgroundColor: c.primary, color: "#fff", borderRadius: theme.borderRadius }} className="px-5 py-2.5 font-bold text-sm">
              Browse Products
            </button>
            <button style={{ backgroundColor: "rgba(255,255,255,0.2)", color: "#fff", borderRadius: theme.borderRadius, border: "1px solid rgba(255,255,255,0.4)" }} className="px-5 py-2.5 font-semibold text-sm">
              Contact Us
            </button>
          </div>
        </div>

        {/* Products Grid */}
        <div className="px-4 py-8 max-w-3xl mx-auto">
          <h2 style={{ color: c.text, fontFamily: theme.fonts.heading }} className="text-xl font-bold mb-5">
            Featured Products
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {sampleProducts.map((p) => (
              <div key={p.name}
                style={{ backgroundColor: c.cardBg, borderRadius: theme.borderRadius, border: `1px solid ${c.border}`, boxShadow: theme.shadow, overflow: "hidden" }}
                className="flex flex-col"
              >
                <div style={{ backgroundColor: c.surfaceAlt }} className="aspect-square flex items-center justify-center text-5xl">
                  {p.emoji}
                </div>
                <div className="p-3">
                  <p style={{ color: c.textMuted }} className="text-[9px] uppercase tracking-wide">{p.cat}</p>
                  <p style={{ color: c.text, fontFamily: theme.fonts.heading }} className="font-bold text-xs mt-0.5">{p.name}</p>
                  <p style={{ color: c.primary }} className="text-[10px] font-bold mt-1">Best Price / kg</p>
                  <div className="flex gap-1.5 mt-2">
                    <button style={{ backgroundColor: c.btnPrimary, color: c.btnPrimaryText, borderRadius: theme.borderRadius }} className="flex-1 py-1.5 text-[10px] font-bold flex items-center justify-center gap-1">
                      <ShoppingCart size={9} /> Add
                    </button>
                    <button style={{ backgroundColor: "#25D366", color: "#fff", borderRadius: theme.borderRadius }} className="p-1.5">
                      <MessageCircle size={11} color="#fff" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <footer style={{ backgroundColor: c.footerBg }} className="px-6 py-8">
          <div className="flex items-center gap-2 mb-3">
            <div style={{ background: `linear-gradient(135deg, ${c.primary}, ${c.accent})` }} className="h-8 w-8 rounded-xl flex items-center justify-center">
              <Leaf size={15} color="#fff" />
            </div>
            <span style={{ color: "#fff", fontFamily: theme.fonts.heading }} className="font-bold text-sm">
              Sardar Vegetable Market
            </span>
          </div>
          <p style={{ color: c.footerText }} className="text-xs opacity-70 mb-4">
            Trusted wholesale vegetables supplier in Surat. Fresh farm produce delivered daily.
          </p>
          <div style={{ borderTop: "1px solid rgba(255,255,255,0.1)" }} className="pt-3">
            <p style={{ color: c.footerText }} className="text-[10px] opacity-50">
              © {new Date().getFullYear()} Sardar Vegetable Market. All rights reserved.
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default function ThemePreviewPage() {
  return (
    <Suspense fallback={<div className="text-white p-8">Loading preview...</div>}>
      <ThemePreviewContent />
    </Suspense>
  );
}
