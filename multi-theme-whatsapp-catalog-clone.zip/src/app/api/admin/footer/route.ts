import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { footerSettings } from "@/db/schema";

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const existing = await db.select().from(footerSettings).limit(1);

    if (existing.length === 0) {
      await db.insert(footerSettings).values(body);
    } else {
      await db.update(footerSettings).set({
        ...body,
        updatedAt: new Date(),
      });
    }

    const [updated] = await db.select().from(footerSettings).limit(1);
    return NextResponse.json({ success: true, data: updated });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
