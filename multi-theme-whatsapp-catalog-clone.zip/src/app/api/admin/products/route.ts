import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products, categories } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const cats = await db.select().from(categories);
    const prods = await db.select().from(products);
    const catMap = Object.fromEntries(cats.map((c) => [c.id, c]));
    const result = prods.map((p) => ({
      ...p,
      category: p.categoryId ? catMap[p.categoryId] : null,
    }));
    return NextResponse.json({ products: result, categories: cats });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const [inserted] = await db.insert(products).values(body).returning();
    return NextResponse.json({ success: true, data: inserted });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
