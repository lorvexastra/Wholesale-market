import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { themeSettings } from "@/db/schema";

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const existing = await db.select().from(themeSettings).limit(1);

    if (existing.length === 0) {
      await db.insert(themeSettings).values({
        activeTheme: body.activeTheme ?? "theme1",
        logoUrl: body.logoUrl ?? null,
        brandName: body.brandName ?? "Sardar Vegetable Market",
      });
    } else {
      await db
        .update(themeSettings)
        .set({
          activeTheme: body.activeTheme ?? existing[0].activeTheme,
          logoUrl: body.logoUrl !== undefined ? body.logoUrl : existing[0].logoUrl,
          brandName: body.brandName ?? existing[0].brandName,
          updatedAt: new Date(),
        });
    }

    const [updated] = await db.select().from(themeSettings).limit(1);
    return NextResponse.json({ success: true, data: updated });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
