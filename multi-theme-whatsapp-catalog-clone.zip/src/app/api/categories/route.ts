import { NextResponse } from "next/server";
import { db } from "@/db";
import { categories } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const cats = await db.select().from(categories).where(eq(categories.isActive, true));
    return NextResponse.json({ categories: cats.sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0)) });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
