import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products, categories } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const categorySlug = searchParams.get("category");
    const featured = searchParams.get("featured");

    const cats = await db.select().from(categories).where(eq(categories.isActive, true));
    const catMap = Object.fromEntries(cats.map((c) => [c.id, c]));

    let query = db
      .select()
      .from(products)
      .where(eq(products.isActive, true));

    const allProducts = await query;

    let filtered = allProducts;

    if (categorySlug) {
      const cat = cats.find((c) => c.slug === categorySlug);
      if (cat) {
        filtered = filtered.filter((p) => p.categoryId === cat.id);
      }
    }

    if (featured === "true") {
      filtered = filtered.filter((p) => p.isFeatured);
    }

    const result = filtered
      .sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0))
      .map((p) => ({
        ...p,
        category: p.categoryId ? catMap[p.categoryId] : null,
      }));

    return NextResponse.json({ products: result, categories: cats });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
