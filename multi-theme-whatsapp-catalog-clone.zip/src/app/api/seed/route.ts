import { NextResponse } from "next/server";
import { db } from "@/db";
import { categories, products, banners, footerSettings, themeSettings } from "@/db/schema";
import { defaultCategories, defaultProducts, defaultBanners, defaultFooterSettings } from "@/lib/data";
import { eq } from "drizzle-orm";

export async function POST() {
  try {
    // Seed categories
    const existingCats = await db.select().from(categories).limit(1);
    if (existingCats.length === 0) {
      await db.insert(categories).values(
        defaultCategories.map((c) => ({
          name: c.name,
          slug: c.slug,
          description: c.description,
          imageUrl: c.imageUrl,
          sortOrder: c.sortOrder,
          isActive: true,
        }))
      );
    }

    // Get category id map
    const cats = await db.select().from(categories);
    const catMap = Object.fromEntries(cats.map((c) => [c.slug, c.id]));

    // Seed products
    const existingProds = await db.select().from(products).limit(1);
    if (existingProds.length === 0) {
      await db.insert(products).values(
        defaultProducts.map((p, i) => ({
          categoryId: catMap[p.categorySlug] ?? null,
          name: p.name,
          slug: p.slug,
          description: p.description,
          unit: p.unit,
          priceLabel: p.priceLabel,
          imageUrl: p.imageUrl,
          tags: p.tags,
          isFeatured: p.isFeatured,
          isActive: true,
          sortOrder: i,
        }))
      );
    }

    // Seed banners
    const existingBanners = await db.select().from(banners).limit(1);
    if (existingBanners.length === 0) {
      await db.insert(banners).values(
        defaultBanners.map((b) => ({
          title: b.title,
          subtitle: b.subtitle,
          imageUrl: b.imageUrl,
          sortOrder: b.sortOrder,
          isActive: true,
        }))
      );
    }

    // Seed footer settings
    const existingFooter = await db.select().from(footerSettings).limit(1);
    if (existingFooter.length === 0) {
      await db.insert(footerSettings).values(defaultFooterSettings);
    }

    // Seed theme settings
    const existingTheme = await db.select().from(themeSettings).limit(1);
    if (existingTheme.length === 0) {
      await db.insert(themeSettings).values({
        activeTheme: "theme1",
        brandName: "Sardar Vegetable Market",
      });
    }

    return NextResponse.json({ success: true, message: "Database seeded successfully" });
  } catch (error) {
    console.error("Seed error:", error);
    return NextResponse.json({ success: false, error: String(error) }, { status: 500 });
  }
}
