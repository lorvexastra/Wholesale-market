import { NextResponse } from "next/server";
import { db } from "@/db";
import { themeSettings, footerSettings } from "@/db/schema";

export async function GET() {
  try {
    const [theme] = await db.select().from(themeSettings).limit(1);
    const [footer] = await db.select().from(footerSettings).limit(1);
    return NextResponse.json({ theme, footer });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
