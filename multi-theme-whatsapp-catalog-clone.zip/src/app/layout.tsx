import type { Metadata, Viewport } from "next";
import "./globals.css";
import { db } from "@/db";
import { themeSettings, footerSettings } from "@/db/schema";
import { ThemeProvider } from "@/context/ThemeContext";
import { CartProvider } from "@/context/CartContext";

export const metadata: Metadata = {
  title: "Sardar Vegetable Market — Fresh Wholesale Vegetables Surat",
  description:
    "Sardar Vegetable Market is a trusted wholesale vegetables supplier in Surat. Fresh farm produce for hotels, restaurants, caterers and retail shops.",
  keywords: "wholesale vegetables surat, fresh vegetables online, sardar vegetable market, vegetable supplier surat",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "SVM",
  },
  openGraph: {
    title: "Sardar Vegetable Market — Fresh Wholesale Vegetables Surat",
    description: "Trusted wholesale vegetables supplier in Surat. Farm fresh produce daily.",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#16a34a",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

async function getInitialSettings() {
  try {
    const [theme] = await db.select().from(themeSettings).limit(1);
    const [footer] = await db.select().from(footerSettings).limit(1);
    return { theme, footer };
  } catch {
    return { theme: null, footer: null };
  }
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const { theme, footer } = await getInitialSettings();

  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <ThemeProvider
          initialThemeId={theme?.activeTheme ?? "theme1"}
          initialBrandName={theme?.brandName ?? "Sardar Vegetable Market"}
          initialLogoUrl={theme?.logoUrl ?? null}
          initialWhatsapp={footer?.whatsappNumber ?? "919876543210"}
        >
          <CartProvider>{children}</CartProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
