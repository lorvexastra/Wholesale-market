"use client";
import React from "react";
import { X, Trash2, Plus, Minus, MessageCircle, ShoppingBag } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { useTheme } from "@/context/ThemeContext";

interface CartDrawerProps {
  open: boolean;
  onClose: () => void;
}

export default function CartDrawer({ open, onClose }: CartDrawerProps) {
  const { items, removeItem, updateQty, clearCart } = useCart();
  const { theme, whatsappNumber } = useTheme();
  const c = theme.colors;

  const buildWhatsAppMessage = () => {
    if (items.length === 0) return "";
    let msg = "🛒 *Enquiry for Vegetables*\n\n";
    items.forEach((item, i) => {
      msg += `${i + 1}. *${item.name}* — ${item.quantity} ${item.unit}\n`;
      if (item.category) msg += `   Category: ${item.category}\n`;
    });
    msg += `\nTotal Items: ${items.length}\n`;
    msg += "\nKindly confirm availability and pricing. Thank you! 🙏";
    return encodeURIComponent(msg);
  };

  const handleWhatsApp = () => {
    const msg = buildWhatsAppMessage();
    const url = `https://wa.me/${whatsappNumber}?text=${msg}`;
    window.open(url, "_blank");
  };

  return (
    <>
      {/* Overlay */}
      {open && (
        <div
          className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm"
          onClick={onClose}
        />
      )}
      {/* Drawer */}
      <div
        className="fixed right-0 top-0 h-full z-50 flex flex-col transition-transform duration-300 ease-in-out"
        style={{
          width: "min(100vw, 420px)",
          backgroundColor: c.surface,
          transform: open ? "translateX(0)" : "translateX(100%)",
          boxShadow: open ? "-8px 0 32px rgba(0,0,0,0.15)" : "none",
          fontFamily: theme.fonts.body,
        }}
      >
        {/* Header */}
        <div
          style={{ backgroundColor: c.primary, color: "#fff" }}
          className="flex items-center justify-between px-5 py-4 flex-shrink-0"
        >
          <div className="flex items-center gap-2">
            <ShoppingBag size={20} />
            <div>
              <p style={{ fontFamily: theme.fonts.heading }} className="font-bold text-lg leading-tight">
                Enquiry Cart
              </p>
              <p className="text-xs opacity-80">{items.length} product{items.length !== 1 ? "s" : ""} selected</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg bg-white/20 hover:bg-white/30 transition-colors">
            <X size={20} />
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center py-16">
              <div
                style={{ backgroundColor: c.surfaceAlt, borderRadius: theme.borderRadius }}
                className="p-6 mb-4"
              >
                <ShoppingBag size={48} style={{ color: c.textMuted }} />
              </div>
              <p style={{ color: c.text, fontFamily: theme.fonts.heading }} className="text-xl font-bold mb-2">
                Cart is empty
              </p>
              <p style={{ color: c.textMuted }} className="text-sm">
                Add products to send an enquiry
              </p>
            </div>
          ) : (
            items.map((item) => (
              <div
                key={item.id}
                style={{
                  backgroundColor: c.surfaceAlt,
                  borderRadius: theme.borderRadius,
                  border: `1px solid ${c.border}`,
                }}
                className="flex items-center gap-3 p-3"
              >
                <div
                  className="w-14 h-14 flex-shrink-0 rounded-xl overflow-hidden bg-gray-100"
                  style={{ borderRadius: theme.borderRadius }}
                >
                  {item.imageUrl ? (
                    <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-2xl">🥬</div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p style={{ color: c.text, fontFamily: theme.fonts.heading }} className="font-semibold text-sm truncate">
                    {item.name}
                  </p>
                  <p style={{ color: c.textMuted }} className="text-xs">{item.category}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <button
                      onClick={() => updateQty(item.id, item.quantity - 1)}
                      style={{
                        backgroundColor: c.primary,
                        color: "#fff",
                        borderRadius: "50%",
                      }}
                      className="w-6 h-6 flex items-center justify-center"
                    >
                      <Minus size={12} />
                    </button>
                    <span style={{ color: c.text }} className="text-sm font-bold w-8 text-center">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateQty(item.id, item.quantity + 1)}
                      style={{
                        backgroundColor: c.primary,
                        color: "#fff",
                        borderRadius: "50%",
                      }}
                      className="w-6 h-6 flex items-center justify-center"
                    >
                      <Plus size={12} />
                    </button>
                    <span style={{ color: c.textMuted }} className="text-xs ml-1">
                      {item.unit}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => removeItem(item.id)}
                  style={{ color: "#ef4444" }}
                  className="p-2 rounded-lg hover:bg-red-50 transition-colors flex-shrink-0"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {items.length > 0 && (
          <div
            style={{
              borderTop: `1px solid ${c.border}`,
              backgroundColor: c.surface,
            }}
            className="px-4 py-4 space-y-3 flex-shrink-0"
          >
            <div
              style={{ backgroundColor: c.surfaceAlt, borderRadius: theme.borderRadius, border: `1px solid ${c.border}` }}
              className="p-3 text-center"
            >
              <p style={{ color: c.textMuted }} className="text-xs mb-1">Enquiry Summary</p>
              <p style={{ color: c.text, fontFamily: theme.fonts.heading }} className="font-bold">
                {items.reduce((s, i) => s + i.quantity, 0)} units across {items.length} products
              </p>
            </div>
            <button
              onClick={handleWhatsApp}
              className="w-full flex items-center justify-center gap-2 py-4 font-bold text-white rounded-2xl text-base transition-all active:scale-95"
              style={{ backgroundColor: "#25D366", borderRadius: theme.borderRadius }}
            >
              <MessageCircle size={20} />
              Send Enquiry on WhatsApp
            </button>
            <button
              onClick={clearCart}
              style={{ color: c.textMuted, borderRadius: theme.borderRadius }}
              className="w-full py-2 text-sm text-center hover:opacity-70 transition-opacity"
            >
              Clear All
            </button>
          </div>
        )}
      </div>
    </>
  );
}
