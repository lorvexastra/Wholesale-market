"use client";
import React, { useRef } from "react";
import { useTheme } from "@/context/ThemeContext";
import { ChevronLeft, ChevronRight } from "lucide-react";
import Link from "next/link";

interface Category {
  id: number;
  name: string;
  slug: string;
  imageUrl: string | null;
}

const EMOJI_MAP: Record<string, string> = {
  "leafy-vegetables": "🥬",
  "root-vegetables": "🥕",
  "gourds-melons": "🎃",
  "exotic-vegetables": "🥦",
  "fruits-pods": "🫑",
  "herbs-spices": "🌿",
};

export default function CategoryScroll({ categories, activeSlug }: { categories: Category[]; activeSlug?: string }) {
  const { theme } = useTheme();
  const c = theme.colors;
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (dir: "left" | "right") => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: dir === "left" ? -200 : 200, behavior: "smooth" });
    }
  };

  return (
    <div className="relative">
      <button
        onClick={() => scroll("left")}
        style={{ backgroundColor: c.surface, border: `1px solid ${c.border}`, color: c.text }}
        className="absolute left-0 top-1/2 -translate-y-1/2 z-10 p-1.5 rounded-full shadow-md hidden md:flex items-center justify-center"
      >
        <ChevronLeft size={16} />
      </button>
      <div
        ref={scrollRef}
        className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide px-1"
        style={{ scrollbarWidth: "none" }}
      >
        <Link
          href="/products"
          style={{
            backgroundColor: !activeSlug ? c.primary : c.surface,
            color: !activeSlug ? "#fff" : c.text,
            border: `1px solid ${!activeSlug ? c.primary : c.border}`,
            borderRadius: theme.borderRadius,
            whiteSpace: "nowrap",
          }}
          className="flex-shrink-0 px-4 py-2 text-sm font-semibold transition-all"
        >
          All Products
        </Link>
        {categories.map((cat) => (
          <Link
            key={cat.id}
            href={`/products?category=${cat.slug}`}
            style={{
              backgroundColor: activeSlug === cat.slug ? c.primary : c.surface,
              color: activeSlug === cat.slug ? "#fff" : c.text,
              border: `1px solid ${activeSlug === cat.slug ? c.primary : c.border}`,
              borderRadius: theme.borderRadius,
              whiteSpace: "nowrap",
            }}
            className="flex-shrink-0 flex items-center gap-2 px-4 py-2 text-sm font-semibold transition-all"
          >
            <span>{EMOJI_MAP[cat.slug] ?? "🥗"}</span>
            <span>{cat.name}</span>
          </Link>
        ))}
      </div>
      <button
        onClick={() => scroll("right")}
        style={{ backgroundColor: c.surface, border: `1px solid ${c.border}`, color: c.text }}
        className="absolute right-0 top-1/2 -translate-y-1/2 z-10 p-1.5 rounded-full shadow-md hidden md:flex items-center justify-center"
      >
        <ChevronRight size={16} />
      </button>
    </div>
  );
}
