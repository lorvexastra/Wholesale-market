"use client";
import React from "react";
import Link from "next/link";
import { useTheme } from "@/context/ThemeContext";
import { Phone, Mail, MapPin, MessageCircle, Clock, Leaf } from "lucide-react";

interface FooterData {
  companyName: string | null;
  companyDescription: string | null;
  address: string | null;
  phone: string | null;
  email: string | null;
  whatsappNumber: string | null;
  instagramUrl: string | null;
  facebookUrl: string | null;
  supportHours: string | null;
}

export default function Footer({ data }: { data: FooterData | null }) {
  const { theme, brandName, logoUrl } = useTheme();
  const c = theme.colors;

  const name = data?.companyName ?? brandName;
  const wp = data?.whatsappNumber ?? "919876543210";

  return (
    <footer style={{ backgroundColor: c.footerBg, color: c.footerText, fontFamily: theme.fonts.body }}>
      {/* Top section */}
      <div className="max-w-6xl mx-auto px-5 py-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {/* Brand */}
        <div className="sm:col-span-2 lg:col-span-1">
          <div className="flex items-center gap-2 mb-4">
            {logoUrl ? (
              <img src={logoUrl} alt={name} className="h-10 w-10 rounded-xl object-cover" />
            ) : (
              <div
                style={{ background: `linear-gradient(135deg, ${c.primary}, ${c.accent})` }}
                className="h-10 w-10 rounded-xl flex items-center justify-center"
              >
                <Leaf size={20} color="#fff" />
              </div>
            )}
            <div>
              <p style={{ fontFamily: theme.fonts.heading, color: "#fff" }} className="font-bold text-sm">
                {name}
              </p>
            </div>
          </div>
          <p className="text-sm leading-relaxed opacity-80 mb-4">
            {data?.companyDescription ?? "Trusted wholesale vegetables supplier. Fresh farm produce delivered directly to your business."}
          </p>
          <div className="flex gap-3">
            {data?.instagramUrl && (
              <a href={data.instagramUrl} target="_blank" rel="noopener noreferrer"
                style={{ backgroundColor: "rgba(255,255,255,0.1)" }}
                className="p-2 rounded-full hover:bg-white/20 transition-colors">
                <span className="text-base">📷</span>
              </a>
            )}
            {data?.facebookUrl && (
              <a href={data.facebookUrl} target="_blank" rel="noopener noreferrer"
                style={{ backgroundColor: "rgba(255,255,255,0.1)" }}
                className="p-2 rounded-full hover:bg-white/20 transition-colors">
                <span className="text-base">👍</span>
              </a>
            )}
            <a href={`https://wa.me/${wp}`} target="_blank" rel="noopener noreferrer"
              style={{ backgroundColor: "#25D366" }}
              className="p-2 rounded-full hover:opacity-80 transition-opacity">
              <MessageCircle size={16} color="#fff" />
            </a>
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h3 style={{ fontFamily: theme.fonts.heading, color: "#fff" }} className="font-bold text-sm mb-4 uppercase tracking-wide">
            Quick Links
          </h3>
          <ul className="space-y-2">
            {[
              { href: "/", label: "Home" },
              { href: "/products", label: "All Products" },
              { href: "/products?category=leafy-vegetables", label: "Leafy Vegetables" },
              { href: "/products?category=root-vegetables", label: "Root Vegetables" },
              { href: "/about", label: "About Us" },
              { href: "/contact", label: "Contact" },
            ].map((link) => (
              <li key={link.href}>
                <Link href={link.href} className="text-sm opacity-70 hover:opacity-100 transition-opacity">
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Contact */}
        <div>
          <h3 style={{ fontFamily: theme.fonts.heading, color: "#fff" }} className="font-bold text-sm mb-4 uppercase tracking-wide">
            Contact
          </h3>
          <ul className="space-y-3">
            {data?.address && (
              <li className="flex items-start gap-2 text-sm opacity-80">
                <MapPin size={14} className="flex-shrink-0 mt-0.5" />
                <span>{data.address}</span>
              </li>
            )}
            {data?.phone && (
              <li>
                <a href={`tel:${data.phone}`} className="flex items-center gap-2 text-sm opacity-80 hover:opacity-100 transition-opacity">
                  <Phone size={14} />
                  <span>{data.phone}</span>
                </a>
              </li>
            )}
            {data?.email && (
              <li>
                <a href={`mailto:${data.email}`} className="flex items-center gap-2 text-sm opacity-80 hover:opacity-100 transition-opacity">
                  <Mail size={14} />
                  <span>{data.email}</span>
                </a>
              </li>
            )}
            {wp && (
              <li>
                <a href={`https://wa.me/${wp}`} target="_blank" rel="noopener noreferrer"
                  className="flex items-center gap-2 text-sm opacity-80 hover:opacity-100 transition-opacity">
                  <MessageCircle size={14} />
                  <span>WhatsApp Us</span>
                </a>
              </li>
            )}
          </ul>
        </div>

        {/* Support */}
        <div>
          <h3 style={{ fontFamily: theme.fonts.heading, color: "#fff" }} className="font-bold text-sm mb-4 uppercase tracking-wide">
            Support Hours
          </h3>
          <div style={{ backgroundColor: "rgba(255,255,255,0.08)", borderRadius: theme.borderRadius }} className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Clock size={16} style={{ color: c.primary }} />
              <span style={{ color: "#fff" }} className="text-sm font-semibold">We&apos;re Available</span>
            </div>
            <p className="text-sm opacity-80">
              {data?.supportHours ?? "Mon - Sun: 4:00 AM – 10:00 AM"}
            </p>
            <div className="mt-4">
              <a
                href={`https://wa.me/${wp}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-sm font-bold text-white transition-all active:scale-95 hover:opacity-90"
                style={{ backgroundColor: "#25D366", borderRadius: theme.borderRadius }}
              >
                <MessageCircle size={15} />
                Order on WhatsApp
              </a>
            </div>
          </div>
          <div className="mt-4 space-y-2">
            {[
              { emoji: "🏨", text: "Hotels & Restaurants" },
              { emoji: "🍽️", text: "Marriage Caterers" },
              { emoji: "🛒", text: "Retail Shops" },
              { emoji: "🏪", text: "Mandi Buyers" },
            ].map((item) => (
              <div key={item.text} className="flex items-center gap-2 text-sm opacity-70">
                <span>{item.emoji}</span>
                <span>{item.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div style={{ borderTop: "1px solid rgba(255,255,255,0.1)" }} className="py-4 px-5 text-center">
        <p className="text-xs opacity-60">
          © {new Date().getFullYear()} {name}. All rights reserved. | Fresh vegetables daily from farms to your table.
        </p>
      </div>
    </footer>
  );
}
