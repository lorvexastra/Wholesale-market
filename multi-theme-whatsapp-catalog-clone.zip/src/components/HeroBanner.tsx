"use client";
import React, { useState, useEffect, useCallback } from "react";
import { useTheme } from "@/context/ThemeContext";
import { ChevronLeft, ChevronRight, Truck, Shield, Clock } from "lucide-react";
import Link from "next/link";

interface Banner {
  id: number;
  title: string;
  subtitle: string | null;
  imageUrl: string | null;
}

export default function HeroBanner({ banners }: { banners: Banner[] }) {
  const { theme } = useTheme();
  const [current, setCurrent] = useState(0);
  const c = theme.colors;

  const next = useCallback(() => setCurrent((p) => (p + 1) % banners.length), [banners.length]);
  const prev = () => setCurrent((p) => (p - 1 + banners.length) % banners.length);

  useEffect(() => {
    const t = setInterval(next, 5000);
    return () => clearInterval(t);
  }, [next]);

  if (!banners.length) return null;

  const banner = banners[current];

  return (
    <div className="relative overflow-hidden" style={{ borderRadius: "0 0 20px 20px" }}>
      {/* Image */}
      <div className="relative h-[55vw] min-h-[220px] max-h-[480px] overflow-hidden">
        {banner.imageUrl && (
          <img
            src={banner.imageUrl}
            alt={banner.title}
            className="w-full h-full object-cover transition-all duration-700"
            key={current}
          />
        )}
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/40 to-transparent" />

        {/* Content */}
        <div className="absolute bottom-0 left-0 right-0 p-5 md:p-8">
          <div
            className="inline-block px-3 py-1 rounded-full text-xs font-semibold mb-3"
            style={{ backgroundColor: c.primary, color: "#fff" }}
          >
            🌿 Wholesale Vegetable Supplier
          </div>
          <h1
            style={{ fontFamily: theme.fonts.heading, color: "#fff" }}
            className="text-xl sm:text-2xl md:text-4xl font-bold leading-tight mb-2 max-w-lg"
          >
            {banner.title}
          </h1>
          {banner.subtitle && (
            <p className="text-white/80 text-sm md:text-base max-w-md mb-4">
              {banner.subtitle}
            </p>
          )}
          <div className="flex flex-wrap gap-3">
            <Link
              href="/products"
              style={{ backgroundColor: c.primary, color: "#fff", borderRadius: theme.borderRadius }}
              className="px-5 py-2.5 font-semibold text-sm transition-all active:scale-95 hover:opacity-90"
            >
              Browse Products
            </Link>
            <Link
              href="/contact"
              style={{ backgroundColor: "rgba(255,255,255,0.2)", color: "#fff", borderRadius: theme.borderRadius, border: "1px solid rgba(255,255,255,0.4)" }}
              className="px-5 py-2.5 font-semibold text-sm backdrop-blur-sm transition-all active:scale-95 hover:bg-white/30"
            >
              Contact Us
            </Link>
          </div>
        </div>

        {/* Nav buttons */}
        {banners.length > 1 && (
          <>
            <button
              onClick={prev}
              className="absolute left-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-white/20 backdrop-blur-sm hover:bg-white/40 transition-colors text-white"
            >
              <ChevronLeft size={18} />
            </button>
            <button
              onClick={next}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-white/20 backdrop-blur-sm hover:bg-white/40 transition-colors text-white"
            >
              <ChevronRight size={18} />
            </button>
          </>
        )}

        {/* Dots */}
        {banners.length > 1 && (
          <div className="absolute bottom-4 right-4 flex gap-1.5">
            {banners.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                style={{
                  backgroundColor: i === current ? "#fff" : "rgba(255,255,255,0.4)",
                  width: i === current ? 20 : 6,
                }}
                className="h-1.5 rounded-full transition-all duration-300"
              />
            ))}
          </div>
        )}
      </div>

      {/* Trust badges */}
      <div
        style={{ backgroundColor: c.surface, borderTop: `1px solid ${c.border}` }}
        className="grid grid-cols-3"
      >
        {[
          { icon: <Truck size={16} />, text: "Daily Fresh Delivery" },
          { icon: <Shield size={16} />, text: "Quality Guaranteed" },
          { icon: <Clock size={16} />, text: "Early Morning Supply" },
        ].map((item, i) => (
          <div
            key={i}
            className="flex flex-col items-center gap-1 py-3 px-2 text-center"
            style={{ borderRight: i < 2 ? `1px solid ${c.border}` : "none" }}
          >
            <div style={{ color: c.primary }}>{item.icon}</div>
            <p style={{ color: c.textMuted }} className="text-[10px] leading-tight font-medium">
              {item.text}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
