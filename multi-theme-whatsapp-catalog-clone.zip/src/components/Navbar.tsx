"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useCart } from "@/context/CartContext";
import { useTheme } from "@/context/ThemeContext";
import { ShoppingCart, Menu, X, Leaf, Search, Phone } from "lucide-react";
import CartDrawer from "./CartDrawer";

export default function Navbar() {
  const { totalItems } = useCart();
  const { theme, brandName, logoUrl } = useTheme();
  const [menuOpen, setMenuOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);

  const c = theme.colors;

  return (
    <>
      <nav
        style={{
          backgroundColor: c.navBg,
          color: c.navText,
          boxShadow: scrolled ? theme.shadow : "none",
          borderBottom: `1px solid ${c.border}`,
          fontFamily: theme.fonts.body,
          transition: "box-shadow 0.2s ease",
        }}
        className="sticky top-0 z-50"
      >
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 min-w-0">
            {logoUrl ? (
              <img src={logoUrl} alt={brandName} className="h-9 w-9 rounded-lg object-cover" />
            ) : (
              <div
                style={{ background: `linear-gradient(135deg, ${c.primary}, ${c.accent})` }}
                className="h-9 w-9 rounded-xl flex items-center justify-center flex-shrink-0"
              >
                <Leaf size={18} color="#fff" />
              </div>
            )}
            <span
              style={{ color: c.navText, fontFamily: theme.fonts.heading, fontWeight: 700 }}
              className="text-base leading-tight truncate hidden sm:block"
            >
              {brandName}
            </span>
            <span
              style={{ color: c.navText, fontFamily: theme.fonts.heading, fontWeight: 700 }}
              className="text-sm leading-tight truncate sm:hidden max-w-[130px]"
            >
              {brandName.split(" ").slice(0, 2).join(" ")}
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-6">
            {[
              { href: "/", label: "Home" },
              { href: "/products", label: "Products" },
              { href: "/about", label: "About" },
              { href: "/contact", label: "Contact" },
            ].map((item) => (
              <Link
                key={item.href}
                href={item.href}
                style={{ color: c.navText, fontFamily: theme.fonts.body }}
                className="text-sm font-medium hover:opacity-70 transition-opacity"
              >
                {item.label}
              </Link>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <Link
              href="/products"
              style={{ color: c.navText }}
              className="p-2 rounded-lg hover:opacity-70 transition-opacity"
              aria-label="Search products"
            >
              <Search size={20} />
            </Link>

            <button
              onClick={() => setCartOpen(true)}
              style={{ backgroundColor: c.btnPrimary, color: c.btnPrimaryText, borderRadius: theme.borderRadius }}
              className="relative flex items-center gap-1.5 px-3 py-2 text-sm font-semibold transition-opacity hover:opacity-90"
            >
              <ShoppingCart size={17} />
              <span className="hidden sm:inline">Enquiry</span>
              {totalItems > 0 && (
                <span
                  style={{ backgroundColor: c.secondary }}
                  className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] rounded-full text-[10px] font-bold text-white flex items-center justify-center px-1"
                >
                  {totalItems}
                </span>
              )}
            </button>

            <button
              onClick={() => setMenuOpen(!menuOpen)}
              style={{ color: c.navText }}
              className="md:hidden p-2 rounded-lg"
              aria-label="Toggle menu"
            >
              {menuOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {menuOpen && (
          <div
            style={{ backgroundColor: c.navBg, borderTop: `1px solid ${c.border}` }}
            className="md:hidden px-4 py-3 space-y-1"
          >
            {[
              { href: "/", label: "🏠 Home" },
              { href: "/products", label: "🥬 Products" },
              { href: "/about", label: "ℹ️ About" },
              { href: "/contact", label: "📞 Contact" },
            ].map((item) => (
              <Link
                key={item.href}
                href={item.href}
                style={{ color: c.navText, borderRadius: theme.borderRadius }}
                className="block px-4 py-3 text-sm font-medium hover:opacity-70 transition-opacity"
                onClick={() => setMenuOpen(false)}
              >
                {item.label}
              </Link>
            ))}
          </div>
        )}
      </nav>

      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} />
    </>
  );
}
