"use client";
import { useEffect, useState } from "react";
import { useTheme } from "@/context/ThemeContext";
import { X, Download } from "lucide-react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: string }>;
}

export default function PWAInstall() {
  const { theme } = useTheme();
  const c = theme.colors;
  const [installEvent, setInstallEvent] = useState<BeforeInstallPromptEvent | null>(null);
  const [show, setShow] = useState(false);

  useEffect(() => {
    // Register service worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(() => {});
    }

    const handler = (e: Event) => {
      e.preventDefault();
      setInstallEvent(e as BeforeInstallPromptEvent);
      const dismissed = sessionStorage.getItem('pwa-dismissed');
      if (!dismissed) setShow(true);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (!installEvent) return;
    await installEvent.prompt();
    const choice = await installEvent.userChoice;
    setShow(false);
    setInstallEvent(null);
  };

  const handleDismiss = () => {
    setShow(false);
    sessionStorage.setItem('pwa-dismissed', '1');
  };

  if (!show) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 max-w-sm mx-auto">
      <div
        style={{
          backgroundColor: c.surface,
          borderRadius: theme.borderRadius,
          border: `1px solid ${c.border}`,
          boxShadow: "0 8px 32px rgba(0,0,0,0.15)",
        }}
        className="flex items-center gap-3 p-4"
      >
        <div
          style={{ backgroundColor: c.primaryLight, borderRadius: theme.borderRadius }}
          className="w-12 h-12 flex items-center justify-center flex-shrink-0"
        >
          <span className="text-2xl">🌿</span>
        </div>
        <div className="flex-1 min-w-0">
          <p style={{ color: c.text, fontFamily: theme.fonts.heading }} className="font-bold text-sm">
            Install App
          </p>
          <p style={{ color: c.textMuted }} className="text-xs">
            Add SVM to your home screen for quick access
          </p>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={handleInstall}
            style={{ backgroundColor: c.primary, color: "#fff", borderRadius: theme.borderRadius }}
            className="flex items-center gap-1 px-3 py-2 text-xs font-bold transition-all active:scale-95"
          >
            <Download size={12} /> Install
          </button>
          <button
            onClick={handleDismiss}
            style={{ color: c.textMuted }}
            className="p-1.5"
          >
            <X size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
