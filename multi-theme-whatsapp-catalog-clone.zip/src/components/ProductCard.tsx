"use client";
import React, { useState } from "react";
import { useCart } from "@/context/CartContext";
import { useTheme } from "@/context/ThemeContext";
import { ShoppingCart, MessageCircle, Check, Star } from "lucide-react";

interface Product {
  id: number;
  name: string;
  unit: string | null;
  priceLabel: string | null;
  imageUrl: string | null;
  description: string | null;
  tags: string | null;
  isFeatured: boolean | null;
  category?: { name: string } | null;
}

interface ProductCardProps {
  product: Product;
  variant?: "grid" | "list";
}

export default function ProductCard({ product, variant = "grid" }: ProductCardProps) {
  const { addItem, items } = useCart();
  const { theme, whatsappNumber } = useTheme();
  const [added, setAdded] = useState(false);
  const c = theme.colors;

  const isInCart = items.some((i) => i.id === product.id);

  const handleAdd = () => {
    addItem({
      id: product.id,
      name: product.name,
      unit: product.unit ?? "kg",
      imageUrl: product.imageUrl,
      category: product.category?.name ?? "",
    });
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const handleDirectEnquiry = () => {
    const msg = encodeURIComponent(
      `Hi! I'm interested in *${product.name}* (${product.unit ?? "kg"}). Please share availability and pricing. Thank you! 🙏`
    );
    window.open(`https://wa.me/${whatsappNumber}?text=${msg}`, "_blank");
  };

  const tags = product.tags ? product.tags.split(",") : [];

  if (variant === "list") {
    return (
      <div
        style={{
          backgroundColor: c.cardBg,
          borderRadius: theme.borderRadius,
          border: `1px solid ${c.border}`,
          boxShadow: theme.shadow,
          fontFamily: theme.fonts.body,
        }}
        className="flex items-center gap-4 p-3 hover:shadow-lg transition-shadow duration-200"
      >
        <div
          className="w-20 h-20 flex-shrink-0 overflow-hidden"
          style={{ borderRadius: theme.borderRadius }}
        >
          {product.imageUrl ? (
            <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" loading="lazy" />
          ) : (
            <div style={{ backgroundColor: c.surfaceAlt }} className="w-full h-full flex items-center justify-center text-3xl">
              🥬
            </div>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 style={{ color: c.text, fontFamily: theme.fonts.heading }} className="font-semibold text-sm">
              {product.name}
            </h3>
            {product.isFeatured && (
              <span style={{ backgroundColor: c.secondary, color: "#fff" }} className="px-1.5 py-0.5 rounded text-[10px] font-bold">
                ⭐ Featured
              </span>
            )}
          </div>
          <p style={{ color: c.textMuted }} className="text-xs mt-0.5">{product.category?.name}</p>
          <p style={{ color: c.primary }} className="text-xs font-semibold mt-1">
            {product.priceLabel} / {product.unit}
          </p>
        </div>
        <div className="flex flex-col gap-2 flex-shrink-0">
          <button
            onClick={handleAdd}
            style={{ backgroundColor: isInCart || added ? c.accent : c.btnPrimary, color: c.btnPrimaryText, borderRadius: theme.borderRadius }}
            className="px-3 py-1.5 text-xs font-semibold flex items-center gap-1 transition-all active:scale-95"
          >
            {added ? <Check size={12} /> : <ShoppingCart size={12} />}
            {added ? "Added!" : isInCart ? "In Cart" : "Add"}
          </button>
          <button
            onClick={handleDirectEnquiry}
            style={{ backgroundColor: "#25D366", color: "#fff", borderRadius: theme.borderRadius }}
            className="px-3 py-1.5 text-xs font-semibold flex items-center gap-1 transition-all active:scale-95"
          >
            <MessageCircle size={12} />
            Enquire
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      style={{
        backgroundColor: c.cardBg,
        borderRadius: theme.borderRadius,
        border: `1px solid ${c.border}`,
        boxShadow: theme.shadow,
        fontFamily: theme.fonts.body,
        overflow: "hidden",
      }}
      className="flex flex-col hover:shadow-xl transition-all duration-200 hover:-translate-y-0.5 group"
    >
      {/* Image */}
      <div className="relative aspect-square overflow-hidden">
        {product.imageUrl ? (
          <img
            src={product.imageUrl}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
          />
        ) : (
          <div style={{ backgroundColor: c.surfaceAlt }} className="w-full h-full flex items-center justify-center text-5xl">
            🥬
          </div>
        )}
        {/* Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {product.isFeatured && (
            <span
              style={{ backgroundColor: c.secondary, color: "#fff" }}
              className="px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1"
            >
              <Star size={9} fill="currentColor" /> Featured
            </span>
          )}
          {tags.includes("organic") && (
            <span className="bg-green-500 text-white px-2 py-0.5 rounded-full text-[10px] font-bold">
              🌱 Organic
            </span>
          )}
        </div>
        {/* Quick enquire overlay */}
        <button
          onClick={handleDirectEnquiry}
          className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 p-2 rounded-full shadow-lg"
          style={{ backgroundColor: "#25D366", color: "#fff" }}
          title="Quick WhatsApp Enquiry"
        >
          <MessageCircle size={16} />
        </button>
      </div>

      {/* Info */}
      <div className="p-3 flex flex-col gap-2 flex-1">
        <div>
          <p style={{ color: c.textMuted }} className="text-[10px] uppercase tracking-wide font-medium mb-0.5">
            {product.category?.name}
          </p>
          <h3
            style={{ color: c.text, fontFamily: theme.fonts.heading }}
            className="font-semibold text-sm leading-tight line-clamp-2"
          >
            {product.name}
          </h3>
        </div>

        {product.priceLabel && (
          <div className="flex items-center gap-1">
            <span style={{ color: c.primary }} className="text-xs font-bold">
              {product.priceLabel}
            </span>
            <span style={{ color: c.textMuted }} className="text-[10px]">
              / {product.unit}
            </span>
          </div>
        )}

        {/* Buttons */}
        <div className="flex gap-2 mt-auto pt-1">
          <button
            onClick={handleAdd}
            style={{
              backgroundColor: isInCart || added ? c.accent : c.btnPrimary,
              color: c.btnPrimaryText,
              borderRadius: theme.borderRadius,
              flex: 1,
            }}
            className="py-2 text-xs font-semibold flex items-center justify-center gap-1 transition-all active:scale-95"
          >
            {added ? <Check size={13} /> : <ShoppingCart size={13} />}
            {added ? "Added!" : isInCart ? "In Cart" : "Add to Cart"}
          </button>
          <button
            onClick={handleDirectEnquiry}
            style={{ backgroundColor: "#25D366", color: "#fff", borderRadius: theme.borderRadius }}
            className="p-2 flex items-center justify-center transition-all active:scale-95"
            title="WhatsApp Enquiry"
          >
            <MessageCircle size={15} />
          </button>
        </div>
      </div>
    </div>
  );
}
