"use client";
import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { Theme, ThemeId, getTheme } from "@/lib/themes";

interface ThemeContextType {
  theme: Theme;
  brandName: string;
  logoUrl: string | null;
  whatsappNumber: string;
  setThemeId: (id: ThemeId) => void;
}

const ThemeContext = createContext<ThemeContextType>({
  theme: getTheme("theme1"),
  brandName: "Sardar Vegetable Market",
  logoUrl: null,
  whatsappNumber: "919876543210",
  setThemeId: () => {},
});

export function ThemeProvider({
  children,
  initialThemeId = "theme1",
  initialBrandName = "Sardar Vegetable Market",
  initialLogoUrl = null,
  initialWhatsapp = "919876543210",
}: {
  children: ReactNode;
  initialThemeId?: string;
  initialBrandName?: string;
  initialLogoUrl?: string | null;
  initialWhatsapp?: string;
}) {
  const [themeId, setThemeId] = useState<ThemeId>(initialThemeId as ThemeId);
  const [brandName] = useState(initialBrandName);
  const [logoUrl] = useState(initialLogoUrl);
  const [whatsappNumber] = useState(initialWhatsapp);

  const theme = getTheme(themeId);

  // Apply CSS variables to :root
  useEffect(() => {
    const root = document.documentElement;
    const c = theme.colors;
    root.style.setProperty("--color-primary", c.primary);
    root.style.setProperty("--color-primary-dark", c.primaryDark);
    root.style.setProperty("--color-primary-light", c.primaryLight);
    root.style.setProperty("--color-secondary", c.secondary);
    root.style.setProperty("--color-accent", c.accent);
    root.style.setProperty("--color-background", c.background);
    root.style.setProperty("--color-surface", c.surface);
    root.style.setProperty("--color-surface-alt", c.surfaceAlt);
    root.style.setProperty("--color-text", c.text);
    root.style.setProperty("--color-text-muted", c.textMuted);
    root.style.setProperty("--color-border", c.border);
    root.style.setProperty("--color-card-bg", c.cardBg);
    root.style.setProperty("--color-nav-bg", c.navBg);
    root.style.setProperty("--color-nav-text", c.navText);
    root.style.setProperty("--color-badge", c.badge);
    root.style.setProperty("--color-badge-text", c.badgeText);
    root.style.setProperty("--color-btn-primary", c.btnPrimary);
    root.style.setProperty("--color-btn-primary-text", c.btnPrimaryText);
    root.style.setProperty("--color-btn-secondary", c.btnSecondary);
    root.style.setProperty("--color-btn-secondary-text", c.btnSecondaryText);
    root.style.setProperty("--color-footer-bg", c.footerBg);
    root.style.setProperty("--color-footer-text", c.footerText);
    root.style.setProperty("--border-radius", theme.borderRadius);
    root.style.setProperty("--shadow", theme.shadow);
    root.style.setProperty("--font-heading", theme.fonts.heading);
    root.style.setProperty("--font-body", theme.fonts.body);

    // Load Google Fonts if not already loaded
    const existing = document.getElementById("theme-font-link");
    if (existing) existing.remove();
    const link = document.createElement("link");
    link.id = "theme-font-link";
    link.rel = "stylesheet";
    link.href = theme.fonts.googleFonts;
    document.head.appendChild(link);

    document.body.style.background = c.background;
    document.body.style.color = c.text;
    document.body.style.fontFamily = theme.fonts.body;
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, brandName, logoUrl, whatsappNumber, setThemeId }}>
      {children}
    </ThemeContext.Provider>
  );
}

export const useTheme = () => useContext(ThemeContext);
