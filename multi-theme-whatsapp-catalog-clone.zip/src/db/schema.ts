import { pgTable, serial, text, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";

export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description"),
  imageUrl: text("image_url"),
  sortOrder: integer("sort_order").default(0),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  categoryId: integer("category_id").references(() => categories.id),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description"),
  unit: text("unit").default("kg"),
  priceLabel: text("price_label"),
  imageUrl: text("image_url"),
  tags: text("tags"),
  isFeatured: boolean("is_featured").default(false),
  isActive: boolean("is_active").default(true),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const banners = pgTable("banners", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  subtitle: text("subtitle"),
  imageUrl: text("image_url"),
  linkUrl: text("link_url"),
  isActive: boolean("is_active").default(true),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const footerSettings = pgTable("footer_settings", {
  id: serial("id").primaryKey(),
  companyName: text("company_name").default("Sardar Vegetable Market"),
  companyDescription: text("company_description"),
  address: text("address"),
  phone: text("phone"),
  email: text("email"),
  whatsappNumber: text("whatsapp_number"),
  instagramUrl: text("instagram_url"),
  facebookUrl: text("facebook_url"),
  supportHours: text("support_hours"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const themeSettings = pgTable("theme_settings", {
  id: serial("id").primaryKey(),
  activeTheme: text("active_theme").default("theme1"),
  logoUrl: text("logo_url"),
  brandName: text("brand_name").default("Sardar Vegetable Market"),
  updatedAt: timestamp("updated_at").defaultNow(),
});
