// Default seed data for the vegetable market

export const defaultCategories = [
  {
    name: "Leafy Vegetables",
    slug: "leafy-vegetables",
    description: "Fresh and crisp leafy greens",
    imageUrl: "https://images.pexels.com/photos/6761085/pexels-photo-6761085.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400",
    sortOrder: 1,
  },
  {
    name: "Root Vegetables",
    slug: "root-vegetables",
    description: "Fresh root vegetables from farms",
    imageUrl: "https://images.pexels.com/photos/4247701/pexels-photo-4247701.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400",
    sortOrder: 2,
  },
  {
    name: "Gourds & Melons",
    slug: "gourds-melons",
    description: "Seasonal gourds and melons",
    imageUrl: "https://images.pexels.com/photos/14092825/pexels-photo-14092825.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400",
    sortOrder: 3,
  },
  {
    name: "Exotic Vegetables",
    slug: "exotic-vegetables",
    description: "Rare and exotic vegetables",
    imageUrl: "https://images.pexels.com/photos/31776842/pexels-photo-31776842.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400",
    sortOrder: 4,
  },
  {
    name: "Fruits & Pods",
    slug: "fruits-pods",
    description: "Peppers, beans and pods",
    imageUrl: "https://images.pexels.com/photos/38675684/pexels-photo-38675684.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400",
    sortOrder: 5,
  },
  {
    name: "Herbs & Spices",
    slug: "herbs-spices",
    description: "Fresh aromatic herbs and spices",
    imageUrl: "https://images.pexels.com/photos/33584156/pexels-photo-33584156.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400",
    sortOrder: 6,
  },
];

export const defaultProducts = [
  // Leafy Vegetables
  { categorySlug: "leafy-vegetables", name: "Spinach (Palak)", slug: "spinach-palak", unit: "kg", priceLabel: "Best Price", isFeatured: true, imageUrl: "https://images.pexels.com/photos/2325843/pexels-photo-2325843.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Fresh farm spinach, rich in iron and nutrients. Perfect for all cooking needs.", tags: "fresh,leafy,organic" },
  { categorySlug: "leafy-vegetables", name: "Fenugreek (Methi)", slug: "fenugreek-methi", unit: "bunch", priceLabel: "Best Price", isFeatured: false, imageUrl: "https://images.pexels.com/photos/4198937/pexels-photo-4198937.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Aromatic fresh fenugreek leaves. Great for dal and sabzi.", tags: "fresh,aromatic" },
  { categorySlug: "leafy-vegetables", name: "Coriander (Dhaniya)", slug: "coriander-dhaniya", unit: "bunch", priceLabel: "Best Price", isFeatured: true, imageUrl: "https://images.pexels.com/photos/2328670/pexels-photo-2328670.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Fresh green coriander, perfect garnish for all Indian dishes.", tags: "fresh,herbs" },
  { categorySlug: "leafy-vegetables", name: "Cabbage (Patta Gobhi)", slug: "cabbage", unit: "kg", priceLabel: "Wholesale Rate", isFeatured: false, imageUrl: "https://images.pexels.com/photos/1199562/pexels-photo-1199562.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Crisp and fresh cabbage heads for bulk orders.", tags: "bulk,fresh" },
  { categorySlug: "leafy-vegetables", name: "Lettuce", slug: "lettuce", unit: "kg", priceLabel: "Best Price", isFeatured: false, imageUrl: "https://images.pexels.com/photos/26951809/pexels-photo-26951809.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Crispy iceberg and romaine lettuce for salads and sandwiches.", tags: "fresh,salad" },

  // Root Vegetables
  { categorySlug: "root-vegetables", name: "Tomato", slug: "tomato", unit: "kg", priceLabel: "Market Price", isFeatured: true, imageUrl: "https://images.pexels.com/photos/4247701/pexels-photo-4247701.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Juicy red tomatoes directly from farms. High quality, great for all uses.", tags: "fresh,popular" },
  { categorySlug: "root-vegetables", name: "Potato (Aloo)", slug: "potato", unit: "kg", priceLabel: "Wholesale Rate", isFeatured: true, imageUrl: "https://images.pexels.com/photos/144248/potatoes-vegetables-erdfrucht-bio-144248.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Premium quality potatoes for wholesale supply to hotels and restaurants.", tags: "bulk,popular,staple" },
  { categorySlug: "root-vegetables", name: "Onion (Pyaaz)", slug: "onion", unit: "kg", priceLabel: "Market Price", isFeatured: true, imageUrl: "https://images.pexels.com/photos/36188439/pexels-photo-36188439.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Fresh red and white onions. Available in bulk for wholesale buyers.", tags: "bulk,essential,popular" },
  { categorySlug: "root-vegetables", name: "Carrot (Gajar)", slug: "carrot", unit: "kg", priceLabel: "Best Price", isFeatured: false, imageUrl: "https://images.pexels.com/photos/143133/pexels-photo-143133.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Sweet and crunchy fresh carrots, ideal for cooking and salads.", tags: "fresh,vitamins" },
  { categorySlug: "root-vegetables", name: "Beetroot", slug: "beetroot", unit: "kg", priceLabel: "Best Price", isFeatured: false, imageUrl: "https://images.pexels.com/photos/6761085/pexels-photo-6761085.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Fresh organic beetroots, high in antioxidants and nutrients.", tags: "fresh,organic,healthy" },
  { categorySlug: "root-vegetables", name: "Radish (Mooli)", slug: "radish", unit: "kg", priceLabel: "Best Price", isFeatured: false, imageUrl: "https://images.pexels.com/photos/6928434/pexels-photo-6928434.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Crisp white radish, excellent for salads and Indian cooking.", tags: "fresh,crunchy" },

  // Gourds & Melons
  { categorySlug: "gourds-melons", name: "Bottle Gourd (Lauki)", slug: "bottle-gourd", unit: "kg", priceLabel: "Best Price", isFeatured: false, imageUrl: "https://images.pexels.com/photos/5767907/pexels-photo-5767907.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Fresh bottle gourds for sabzi and dal. Wholesale supply available.", tags: "fresh,gourd" },
  { categorySlug: "gourds-melons", name: "Bitter Gourd (Karela)", slug: "bitter-gourd", unit: "kg", priceLabel: "Best Price", isFeatured: false, imageUrl: "https://images.pexels.com/photos/5639411/pexels-photo-5639411.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Fresh bitter gourd with medicinal properties. Great for health-conscious buyers.", tags: "fresh,healthy,medicinal" },
  { categorySlug: "gourds-melons", name: "Pumpkin (Kaddu)", slug: "pumpkin", unit: "kg", priceLabel: "Wholesale Rate", isFeatured: true, imageUrl: "https://images.pexels.com/photos/14092825/pexels-photo-14092825.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Orange pumpkins, perfect for curries and festive cooking.", tags: "seasonal,bulk" },
  { categorySlug: "gourds-melons", name: "Ridge Gourd (Turai)", slug: "ridge-gourd", unit: "kg", priceLabel: "Best Price", isFeatured: false, imageUrl: "https://images.pexels.com/photos/8471929/pexels-photo-8471929.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Fresh ridge gourd for daily cooking. Available fresh daily.", tags: "fresh,daily" },

  // Exotic Vegetables
  { categorySlug: "exotic-vegetables", name: "Broccoli", slug: "broccoli", unit: "kg", priceLabel: "Premium Price", isFeatured: true, imageUrl: "https://images.pexels.com/photos/1353361/pexels-photo-1353361.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Fresh broccoli for hotels and restaurants. Premium quality imported variety.", tags: "premium,exotic,restaurant" },
  { categorySlug: "exotic-vegetables", name: "Baby Corn", slug: "baby-corn", unit: "kg", priceLabel: "Best Price", isFeatured: true, imageUrl: "https://images.pexels.com/photos/4226869/pexels-photo-4226869.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Tender baby corn for Chinese, Thai and continental cuisines.", tags: "exotic,restaurant,premium" },
  { categorySlug: "exotic-vegetables", name: "Mushroom", slug: "mushroom", unit: "kg", priceLabel: "Market Price", isFeatured: false, imageUrl: "https://images.pexels.com/photos/1143754/pexels-photo-1143754.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Fresh button and oyster mushrooms. Perfect for gourmet cooking.", tags: "exotic,premium,gourmet" },
  { categorySlug: "exotic-vegetables", name: "Zucchini", slug: "zucchini", unit: "kg", priceLabel: "Premium Price", isFeatured: false, imageUrl: "https://images.pexels.com/photos/4207892/pexels-photo-4207892.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Fresh green and yellow zucchini for continental dishes.", tags: "exotic,continental,premium" },

  // Fruits & Pods
  { categorySlug: "fruits-pods", name: "Green Chilli (Hari Mirch)", slug: "green-chilli", unit: "kg", priceLabel: "Best Price", isFeatured: false, imageUrl: "https://images.pexels.com/photos/38675684/pexels-photo-38675684.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Hot and fresh green chillies. Essential for Indian cooking.", tags: "fresh,spicy,essential" },
  { categorySlug: "fruits-pods", name: "Capsicum (Shimla Mirch)", slug: "capsicum", unit: "kg", priceLabel: "Best Price", isFeatured: true, imageUrl: "https://images.pexels.com/photos/1435735/pexels-photo-1435735.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Colorful capsicums - red, yellow, and green. Perfect for salads and cooking.", tags: "colorful,fresh,popular" },
  { categorySlug: "fruits-pods", name: "Peas (Matar)", slug: "peas", unit: "kg", priceLabel: "Seasonal Rate", isFeatured: false, imageUrl: "https://images.pexels.com/photos/5604885/pexels-photo-5604885.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Fresh green peas in season. Sweet and tender for all dishes.", tags: "seasonal,fresh,sweet" },
  { categorySlug: "fruits-pods", name: "French Beans", slug: "french-beans", unit: "kg", priceLabel: "Best Price", isFeatured: false, imageUrl: "https://images.pexels.com/photos/8471929/pexels-photo-8471929.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Crisp and tender French beans for stir-fries and curries.", tags: "fresh,crispy" },

  // Herbs & Spices
  { categorySlug: "herbs-spices", name: "Garlic (Lahsun)", slug: "garlic", unit: "kg", priceLabel: "Best Price", isFeatured: true, imageUrl: "https://images.pexels.com/photos/33584156/pexels-photo-33584156.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Fresh and aromatic garlic bulbs. Essential for every kitchen.", tags: "aromatic,essential,fresh" },
  { categorySlug: "herbs-spices", name: "Ginger (Adrak)", slug: "ginger", unit: "kg", priceLabel: "Market Price", isFeatured: false, imageUrl: "https://images.pexels.com/photos/4197447/pexels-photo-4197447.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Fresh ginger root, aromatic and flavorful for curries and tea.", tags: "aromatic,fresh,medicinal" },
  { categorySlug: "herbs-spices", name: "Curry Leaves (Kadi Patta)", slug: "curry-leaves", unit: "bunch", priceLabel: "Best Price", isFeatured: false, imageUrl: "https://images.pexels.com/photos/2328670/pexels-photo-2328670.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Fresh curry leaves for authentic South Indian cooking.", tags: "fresh,aromatic,south-indian" },
  { categorySlug: "herbs-spices", name: "Mint (Pudina)", slug: "mint-pudina", unit: "bunch", priceLabel: "Best Price", isFeatured: false, imageUrl: "https://images.pexels.com/photos/2325843/pexels-photo-2325843.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=400&w=400", description: "Fresh aromatic mint leaves. Perfect for chutneys, raitas and drinks.", tags: "fresh,aromatic,cooling" },
];

export const defaultBanners = [
  {
    title: "Fresh Vegetables Direct From Farm",
    subtitle: "Wholesale supplier for hotels, restaurants & caterers in Surat",
    imageUrl: "https://images.pexels.com/photos/31776842/pexels-photo-31776842.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=800&w=1400",
    sortOrder: 1,
  },
  {
    title: "Same Market Price, Door Delivery",
    subtitle: "Order online and get fresh farm vegetables at Sardar Market Surat prices",
    imageUrl: "https://images.pexels.com/photos/37624650/pexels-photo-37624650.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=800&w=1400",
    sortOrder: 2,
  },
  {
    title: "Bulk Orders Welcome",
    subtitle: "Hotels, Marriage Halls, Restaurants & Mandi buyers — we supply fresh daily",
    imageUrl: "https://images.pexels.com/photos/15922879/pexels-photo-15922879.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=800&w=1400",
    sortOrder: 3,
  },
];

export const defaultFooterSettings = {
  companyName: "Sardar Vegetable Market",
  companyDescription: "Trusted wholesale vegetables supplier in Surat. Fresh farm produce delivered directly to your business.",
  address: "Sardar Vegetable Market, Surat, Gujarat - 395003",
  phone: "+91 98765 43210",
  email: "info@sardarvegetablemarket.in",
  whatsappNumber: "919876543210",
  instagramUrl: "https://instagram.com/sardarvegetablemarket",
  facebookUrl: "https://facebook.com/sardarvegetablemarket",
  supportHours: "Mon - Sun: 4:00 AM – 10:00 AM",
};
