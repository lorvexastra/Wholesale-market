export type ThemeId = "theme1" | "theme2" | "theme3" | "theme4" | "theme5";

export interface Theme {
  id: ThemeId;
  name: string;
  description: string;
  preview: string;
  fonts: {
    heading: string;
    body: string;
    googleFonts: string;
  };
  colors: {
    primary: string;
    primaryDark: string;
    primaryLight: string;
    secondary: string;
    accent: string;
    background: string;
    surface: string;
    surfaceAlt: string;
    text: string;
    textMuted: string;
    border: string;
    cardBg: string;
    navBg: string;
    navText: string;
    badge: string;
    badgeText: string;
    btnPrimary: string;
    btnPrimaryText: string;
    btnSecondary: string;
    btnSecondaryText: string;
    heroBg: string;
    heroText: string;
    footerBg: string;
    footerText: string;
  };
  borderRadius: string;
  shadow: string;
}

export const themes: Record<ThemeId, Theme> = {
  theme1: {
    id: "theme1",
    name: "Fresh Green",
    description: "Clean & organic — lush greens with a modern minimalist look",
    preview: "bg-gradient-to-br from-emerald-500 to-green-700",
    fonts: {
      heading: "'DM Sans', sans-serif",
      body: "'DM Sans', sans-serif",
      googleFonts: "https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800&display=swap",
    },
    colors: {
      primary: "#16a34a",
      primaryDark: "#15803d",
      primaryLight: "#dcfce7",
      secondary: "#f59e0b",
      accent: "#10b981",
      background: "#f9fafb",
      surface: "#ffffff",
      surfaceAlt: "#f0fdf4",
      text: "#111827",
      textMuted: "#6b7280",
      border: "#e5e7eb",
      cardBg: "#ffffff",
      navBg: "#ffffff",
      navText: "#111827",
      badge: "#16a34a",
      badgeText: "#ffffff",
      btnPrimary: "#16a34a",
      btnPrimaryText: "#ffffff",
      btnSecondary: "#f0fdf4",
      btnSecondaryText: "#16a34a",
      heroBg: "linear-gradient(135deg, #064e3b 0%, #16a34a 50%, #4ade80 100%)",
      heroText: "#ffffff",
      footerBg: "#064e3b",
      footerText: "#d1fae5",
    },
    borderRadius: "12px",
    shadow: "0 4px 24px rgba(22,163,74,0.10)",
  },
  theme2: {
    id: "theme2",
    name: "Earthy Harvest",
    description: "Warm terracotta & amber tones — rustic farm-to-table charm",
    preview: "bg-gradient-to-br from-amber-500 to-orange-700",
    fonts: {
      heading: "'Playfair Display', serif",
      body: "'Lato', sans-serif",
      googleFonts:
        "https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800&family=Lato:wght@300;400;700&display=swap",
    },
    colors: {
      primary: "#d97706",
      primaryDark: "#b45309",
      primaryLight: "#fef3c7",
      secondary: "#16a34a",
      accent: "#f59e0b",
      background: "#fffbf0",
      surface: "#ffffff",
      surfaceAlt: "#fef9ee",
      text: "#1c1007",
      textMuted: "#92400e",
      border: "#fde68a",
      cardBg: "#fffdf5",
      navBg: "#78350f",
      navText: "#fef3c7",
      badge: "#d97706",
      badgeText: "#ffffff",
      btnPrimary: "#d97706",
      btnPrimaryText: "#ffffff",
      btnSecondary: "#fef3c7",
      btnSecondaryText: "#92400e",
      heroBg: "linear-gradient(135deg, #78350f 0%, #d97706 50%, #fbbf24 100%)",
      heroText: "#ffffff",
      footerBg: "#1c1007",
      footerText: "#fde68a",
    },
    borderRadius: "8px",
    shadow: "0 4px 24px rgba(217,119,6,0.12)",
  },
  theme3: {
    id: "theme3",
    name: "Midnight Premium",
    description: "Dark luxury — sleek, bold & modern premium aesthetic",
    preview: "bg-gradient-to-br from-slate-800 to-slate-950",
    fonts: {
      heading: "'Space Grotesk', sans-serif",
      body: "'Inter', sans-serif",
      googleFonts:
        "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600&display=swap",
    },
    colors: {
      primary: "#22d3ee",
      primaryDark: "#0891b2",
      primaryLight: "#ecfeff",
      secondary: "#a3e635",
      accent: "#f472b6",
      background: "#0f172a",
      surface: "#1e293b",
      surfaceAlt: "#162032",
      text: "#f1f5f9",
      textMuted: "#94a3b8",
      border: "#334155",
      cardBg: "#1e293b",
      navBg: "#0f172a",
      navText: "#f1f5f9",
      badge: "#22d3ee",
      badgeText: "#0f172a",
      btnPrimary: "#22d3ee",
      btnPrimaryText: "#0f172a",
      btnSecondary: "#1e293b",
      btnSecondaryText: "#22d3ee",
      heroBg: "linear-gradient(135deg, #020617 0%, #0f172a 50%, #1e3a5f 100%)",
      heroText: "#f1f5f9",
      footerBg: "#020617",
      footerText: "#94a3b8",
    },
    borderRadius: "16px",
    shadow: "0 4px 32px rgba(34,211,238,0.15)",
  },
  theme4: {
    id: "theme4",
    name: "Rose Blossom",
    description: "Soft rose & lavender — elegant, feminine & boutique-style",
    preview: "bg-gradient-to-br from-rose-400 to-pink-700",
    fonts: {
      heading: "'Cormorant Garamond', serif",
      body: "'Nunito', sans-serif",
      googleFonts:
        "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600;700&family=Nunito:wght@300;400;600;700&display=swap",
    },
    colors: {
      primary: "#e11d48",
      primaryDark: "#be123c",
      primaryLight: "#fff1f2",
      secondary: "#7c3aed",
      accent: "#f43f5e",
      background: "#fff9fb",
      surface: "#ffffff",
      surfaceAlt: "#fdf2f8",
      text: "#1f0a14",
      textMuted: "#9d3e5c",
      border: "#fce7f3",
      cardBg: "#ffffff",
      navBg: "#ffffff",
      navText: "#1f0a14",
      badge: "#e11d48",
      badgeText: "#ffffff",
      btnPrimary: "#e11d48",
      btnPrimaryText: "#ffffff",
      btnSecondary: "#fff1f2",
      btnSecondaryText: "#be123c",
      heroBg: "linear-gradient(135deg, #881337 0%, #e11d48 50%, #fb7185 100%)",
      heroText: "#ffffff",
      footerBg: "#1f0a14",
      footerText: "#fce7f3",
    },
    borderRadius: "20px",
    shadow: "0 4px 24px rgba(225,29,72,0.12)",
  },
  theme5: {
    id: "theme5",
    name: "Ocean Fresh",
    description: "Crisp blues & teals — clean, trust-building seafood-market style",
    preview: "bg-gradient-to-br from-blue-500 to-teal-700",
    fonts: {
      heading: "'Josefin Sans', sans-serif",
      body: "'Source Sans 3', sans-serif",
      googleFonts:
        "https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@300;400;600;700&family=Source+Sans+3:wght@300;400;600;700&display=swap",
    },
    colors: {
      primary: "#0284c7",
      primaryDark: "#0369a1",
      primaryLight: "#e0f2fe",
      secondary: "#0d9488",
      accent: "#38bdf8",
      background: "#f0f9ff",
      surface: "#ffffff",
      surfaceAlt: "#e0f2fe",
      text: "#0c1a2e",
      textMuted: "#4b7a9b",
      border: "#bae6fd",
      cardBg: "#ffffff",
      navBg: "#0c4a6e",
      navText: "#e0f2fe",
      badge: "#0284c7",
      badgeText: "#ffffff",
      btnPrimary: "#0284c7",
      btnPrimaryText: "#ffffff",
      btnSecondary: "#e0f2fe",
      btnSecondaryText: "#0369a1",
      heroBg: "linear-gradient(135deg, #0c4a6e 0%, #0284c7 50%, #38bdf8 100%)",
      heroText: "#ffffff",
      footerBg: "#0c2340",
      footerText: "#bae6fd",
    },
    borderRadius: "10px",
    shadow: "0 4px 24px rgba(2,132,199,0.12)",
  },
};

export function getTheme(id: string): Theme {
  return themes[(id as ThemeId)] ?? themes.theme1;
}
